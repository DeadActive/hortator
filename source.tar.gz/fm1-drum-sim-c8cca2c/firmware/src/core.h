/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
 * Drum machine fork: 2026 DEADACTIVE */
/* Drum machine core types: 8 drum tracks; each plays one drum model (1 or 2 voices) and an
 * optional sample layer, through Felucca's per-track DIST / INSERT / SLICER / sends (fx.c). */
#include <stdint.h>
#include "dm_state.h"
#define NTRK 8                   /* drum tracks */
#define NPART NTRK               /* fx.c / slicer.c: every track is mixed the same way */
#define NDV 2                    /* voices per track; a model uses 1 or 2 */
#define NSTEP 64
#define HALF_FRAMES 256          /* I2S half buffer: 5.8 ms at 44.1 kHz */
#define UP_SLOTS 32u             /* user preset slots (storage layout; presets are off in M1) */

/* ------------------------------------------------------- parameters --- */
enum {
    F_INT, F_PCT, F_BIPCT, F_TIME, F_LFOHZ, F_CUTOFF, F_DB, F_SEMI, F_ENUM, F_BPM, F_NOTE,
    F_ONOFF, F_OCT, F_STEPS, F_CTHR, F_CRAT, F_CATK, F_CREL, F_CMKUP, F_LRATE1, F_LRATE2, F_LDEST, F_LPHASE,
    F_NOTEO, F_RDECAY, F_FDEC, F_SRR, F_SLOT, F_LSLOT   /* SLOT: the SAMPLE model's (its SET), the LAYER's (LAYER SET) */
};

typedef struct {
    const char *label;
    uint8_t fmt;
    int16_t min, max, def;
    const char *const *names;   /* F_ENUM */
    const char *unit;           /* F_INT / F_ENUM optional unit */
} param_desc_t;
#define PD(l, f, mn, mx, df) {l, f, mn, mx, df, 0, 0}
#define PE(l, n, df) {l, F_ENUM, 0, (int16_t)(sizeof(n) / sizeof(n[0]) - 1), df, n, 0}

enum { LF_WAVE, LF_MODE, LF_RATE, LF_MORPH, LF_DEPTH, LF_DEST, LF_TRIG, LF_PHASE, LF_N };   /* an LFO's knobs */
enum { LW_SQUARE, LW_SAW, LW_RSAW, LW_SINE, LW_TRI, LW_SH, LW_WANDER, LW_EXPUP, LW_EXPDN, LW_RWALK, LW_COUNT };   /* LFO waves (lfo.c) */
enum { LM_SYNC, LM_HZ, LM_TIME };
enum { LT_FREE, LT_HIT, LT_PLAY };
enum { RS_OFF, RS_STRNG, RS_PIPE, RS_CHORD, RS_MODAL, RS_NMODEL };   /* RESON models (reson.c); MODAL: the modal core (phys_dsp.c) */
enum { FT_OFF, FT_LP, FT_BP, FT_HP, FT_NOTCH, FT_N };   /* FILTER types (filter.c) */
enum { IT_OFF, IT_SOFT, IT_HARD, IT_FOLD, IT_FUZZ, IT_CRUSH, IT_PHASER, IT_FLANGER, IT_CHORUS, IT_N };   /* INSERT
                                                     * types (insert.c; stored: append only) */
#define RS_NCHORD 20                                 /* CHORD types (reson.c RS_CHORD_IV, params.c N_RCHORD) */

enum {                          /* per-track parameters */
    P_MODEL,
    P_E0, P_E1, P_E2, P_E3, P_E4, P_E5, P_E6, P_E7,   /* the model's: TUNE DECAY TONE CHAR + 4 extras */
    P_LEVEL, P_PAN, P_MUTE, P_CHOKE, P_NOTE,
    P_DIST, P_CHOR, P_DLY, P_REV,
    P_SLCR, P_SLPAT, P_SLRATE, P_SLDEPTH,
    P_SLEN, P_SDIV, P_SSWING,
    P_LSET, P_LKEY, P_LLEVEL, P_LTUNE, P_LDEC,       /* sample layer */
    P_SRC,                       /* what the track plays: 0 its steps, 1..3 a Grids channel (kick, snare, hats) */
    P_DUCK,                      /* M3: the COMP source ducks this track */
    P_LFO1,                      /* LFO 1: LF_N knobs (lfo.c) */
    P_LFO2 = P_LFO1 + LF_N,      /* LFO 2 */
    P_RMODEL = P_LFO2 + LF_N,    /* RESON (reson.c): MODEL TUNE DECAY MIX, TONE STRCT POS */
    P_RTUNE, P_RDECAY, P_RMIX, P_RTONE, P_RSTRCT, P_RPOS,
    P_FTYPE, P_FCUT, P_FRESO, P_FENV, P_FDEC,   /* FILTER (filter.c): TYPE CUT RESO ENV DECAY */
    P_PRIO,                      /* 0 HIGH, 1 LOW: a LOW track's voice goes first (the voice cap, a CPU shed; FDRC) */
    P_LSRC1, P_LSRC2,            /* the LFO DEST slots (lfo.c LS_ID; FDRE): slot 1 / 2's SRC (0 LFO 1, 1 LFO 2); their
                                  * DEST / DEPTH are LFO 1's / LFO 2's own (P_LFO1 / P_LFO2 + LF_DEST, LF_DEPTH) */
    P_LS3SRC, P_LS3DEST, P_LS3DEPTH,   /* slot 3: SRC DEST DEPTH */
    P_LS4SRC, P_LS4DEST, P_LS4DEPTH,   /* slot 4 */
    P_RKEY,                      /* RESON KEYF (reson.c): how far the ring follows the hit's note from C4, 0..127 = 0..100 %.
                                  * Past the project's parameter block (FDRE fills its sector): stored in the steps' spare
                                  * byte (project.c) */
    P_SRR,                       /* SRR (insert.c): sample rate reduction before DIST, 0 off .. 127 (347 Hz) */
    P_ITYPE, P_IA, P_IB, P_IC, P_IMIX,   /* INSERT (insert.c, Skiff's from Felucca 1.5): TYPE, its A B C, MIX */
    P_SATK, P_SSUS, P_SREL, P_SLOOP,     /* the SAMPLE model's envelope and loop (dm_sample.c): ATK SUS REL LOOP, its
                                          * SOUND page 5/5. Stored past the project's xp (project.c xp2) */
    P_SPLAY,                     /* the SAMPLE model's PLAY (dm_sample.c): 0 KEY (as before), 1 CHOP (a hit's note picks
                                  * the set's sample); SOUND 4/5. project.c xp3 */
    P_SCUT,                      /* .. CUT: 0 OFF (as before: hits overlap), 1 ON (a hit cuts the sounding one); xp3 */
    P_COUNT
};
#define P_NSTORED P_RKEY         /* the parameters in a project's block (FDRE: P_MODEL .. P_LS4DEPTH) */

enum {                          /* global parameters */
    G_BPM, G_SWING, G_CLOCK,
    G_DTIME, G_DFDBK, G_DCOLOR, G_DMIX,
    G_RSIZE, G_RDAMP, G_CRATE, G_CDEPTH,
    G_MIDI, G_SYNC, G_ROUTE, G_INFO,   /* G_MIDI: the USB state (shown); SYNC: MIDI clock out (SY_ bits, midi_out.c);
                                        * ROUT: MIDI in routing (RT_, seq.c midi_block); both stored, 0 before */
    G_SLOT, G_NAME, G_LOAD, G_SAVE,
    G_CLRSEQ, G_INITSND,
    G_DRCH,                      /* MIDI channel of the drum tracks, 1..16 */
    G_GMODE, G_GX, G_GY, G_GCHAOS,                   /* Grids (grids.c): MAP / EUCLID, the map point, chaos */
    G_GFILL1, G_GFILL2, G_GFILL3,                    /* fill per channel (kick, snare, hats) */
    G_GLEN1, G_GLEN2, G_GLEN3,                       /* Euclidean length per channel, 1..32 sixteenths */
    G_CSRC, G_CTHR, G_CRAT, G_CREL,                  /* COMP (comp.c): source track (0 off), threshold, ratio, release */
    G_CATK, G_CKNEE, G_CMKUP,                        /* attack, soft knee, makeup (127 = limiter) */
    G_CGHOST,                                        /* a muted / any source heard: CG_MUTE CG_KEEP CG_HIDE (fx.c) */
    G_RTYPE,                                         /* REVERB TYPE (fx.c): 0 ROOM, 1 SPRING (sound pack, FDR7), 2 HALL */
    G_DMODE,                                         /* DLY MODE (fx.c): 0 NORMAL, 1 PING-PONG. Past the project's
                                                      * globals (G_NSTORED): stored in its reserved byte rsv[0]
                                                      * (project.c; every earlier firmware wrote 0 there: NORMAL) */
    G_COUNT
};
#define G_NSTORED G_DMODE        /* the globals in a project's block (FDR7 .. FDRF: G_BPM .. G_RTYPE) */
enum { CG_MUTE, CG_KEEP, CG_HIDE };                 /* GHOST: muted = muted; muted still keys; never heard, keys */
enum { G_CLRALL = G_COUNT, G_INITALL, G_MUTEBAR, G_METRO, G_COPY, G_PASTE, G_THRU, G_QUANT };   /* TOOLS actions, the
                                                     * MUTE and METRO settings, COPY / PASTE of a slot (spec 2026-10-26),
                                                     * the THRU setting (midi_out.c), QUANT (seq.c rec_quant, spec
                                                     * 2026-10-31): shown like globals, not stored in projects */
#define SY_USB 1u                                   /* G_SYNC: the outputs the clock goes to (OFF 0, USB 1, BLE 2, BOTH 3) */
#define SY_BLE 2u
enum { RT_NOTE, RT_SEL, RT_TRACK };                 /* G_ROUTE: a note on CH plays the tracks with its NOTE; on CH, the
                                                     * selected track pitched from C4; channel 1..8 track 1..8, pitched */

/* ----------------------------------------------------------- voices --- */
typedef struct {                 /* sample playback state (eng_sample.c sample_next, dm_sample.c) */
    uint32_t ph[3];              /* ph[0] position, ph[1] fraction Q16 */
    int32_t s[8];                /* s[0] predictor, s[1] step index, s[2..3] interpolation, s[4] zone,
                                  * s[5] step Q16, s[6] tone state */
} voice_t;

typedef struct { int32_t a1, a2, a3, k; } dsvf_t;   /* dm_dsp.c: SVF with LP / BP / HP */

typedef struct {                 /* one drum voice; the fields' meaning is the model's */
    uint8_t active, vel;
    uint32_t age;                /* hit order (voice stealing) */
    uint32_t t;                  /* samples since the hit (models that need it) */
    uint32_t ph[3], inc[3];      /* oscillator phases and increments */
    int32_t env[3];              /* envelopes, Q24 (1 << 24 = full) */
    uint32_t k[3];               /* their per-sample factors, Q16 (DECAY_K) */
    dsvf_t c[2];                 /* filters */
    int32_t f[4];                /* filter states (2 per filter) */
    int32_t x[4];                /* model scratch: gains, amounts */
    int32_t rng;                 /* noise state, seeded per hit */
    int32_t last;                /* last sample added to the output (declick when cut) */
    voice_t sv;                  /* sample playback (SAMPLE model, layer) */
    dm_state_t ms;               /* M1-C model state (dm_state.h) */
} dvoice_t;

struct track;
typedef struct {
    const char *name;            /* <= 5 chars (UI value) */
    uint8_t voices;              /* 1 or 2 */
    uint8_t choke;               /* default choke group, 0 = none */
    param_desc_t edit[8];        /* P_E0..P_E7: TUNE DECAY TONE CHAR + 4 extras */
    void (*trigger)(struct track *t, dvoice_t *v);
    void (*render)(struct track *t, dvoice_t *v, int32_t *out, uint32_t n);
    uint8_t weight;              /* what a voice counts toward DRUM_MAXV: 0 / 1 = 1, 2 = a heavy model (M1-C) */
    void (*glide)(struct track *t, dvoice_t *v);         /* ACID: the voice moves to the track's note, no restart */
    void (*gate)(struct track *t, dvoice_t *v, int open); /* ACID: 0 = the gate closes (release) */
} dmodel_t;

/* ------------------------------------------------------------ track --- */
typedef struct {                 /* one sequencer step (4 B, stored as is); all zero = a plain step, off, at C4 */
    uint8_t on : 1, acc : 1;     /* hit; accent (velocity 127, else 96) */
    uint8_t slide : 1, tie : 1;  /* ACID: glide into the next note / hold the sounding note through this step */
    uint8_t rat : 2;             /* RATCH: hits - 1 (0..3) */
    uint8_t : 2;
    uint8_t cond;                /* PROB: 0 = 100 %, 1..20 = 0..95 %, 21 = 1-SHOT, 22..56 = A/B (params.c cond_*) */
    int8_t nt;                   /* NOTE - 60 (C4 = 0): a drum's transpose, ACID's note (NT_MIN..NT_MAX) */
    union {                      /* MICRO (spec 2026-10-31 §1): the hit moved by micro / 100 of a step, -50..+50 (seq.c
                                  * step_micro); the byte was the spare one (rsv, 0 before): its old name kept */
        int8_t micro;
        uint8_t rsv;
    };
} step_t;
#define MICRO_MAX 50
#define NT_MIN (-60)
#define NT_MAX 67
#define GATE_HELD 0xFFFFFFFFu     /* track_t.gate_n: the gate stays open, the next step decides (seq.c acid_step) */

typedef struct { uint32_t ph, sub; int32_t out, from, to; uint8_t fresh; } lfo_state_t;   /* lfo.c: phase, sub-phase,
                                                                           * outputs, restarted */

typedef struct {                 /* RESON runtime (reson.c): per line (STRNG / PIPE 1, CHORD 4) */
    uint32_t len[4];             /* the line's delay, Q8 samples (the loop filters' delay taken off) */
    int32_t g[4];                /* loop gain, Q15 (PIPE: negative) */
    int32_t lp[4], lr[4], apx[4], apy[4];   /* damping low-pass and its step's remainder; the all-pass' x, y[n-1] */
    int32_t k, a;                /* damping coefficient (Q15), all-pass coefficient (Q15, <= 0) */
    uint16_t tap[4];             /* POS: the second pickup tap (0 = none) */
    uint16_t w, seg, quiet, peak;   /* write position, segment length, quiet blocks, last block's line peak */
    uint8_t ns, model, ring, kill;  /* lines, the model running, ringing, fade out this block */
    uint8_t hold;                /* after a cut: no input until the track's next hit (its declick tail excites nothing) */
    int8_t knt;                  /* KEYF: the last hit's note (offset from C4) */
    int32_t kq;                  /* KEYF: the pitch offset playing, 1/256 semitone (glides to knt x KEYF while it rings) */
} reson_t;

typedef struct track {
    int16_t p[P_COUNT];
    uint8_t model;               /* model the voices were started with (a change cuts them) */
    dvoice_t v[NDV];             /* model voices */
    dvoice_t lv[NDV];            /* sample-layer voices */
    int32_t dtail;               /* declick: last output of cut voices, decaying */
    /* sequencer */
    step_t step[NSTEP];
    int8_t nt;                   /* the playing note's offset from C4 (the step's, 0 for MIDI, keys): models read TUNE through dm_tune */
    uint32_t gate_n;             /* ACID: samples until its gate closes, GATE_HELD while the next step decides, 0 closed */
    uint8_t slide_in;            /* ACID: the previous step slides into this one */
    int8_t rat_nt;               /* RATCH: the roll's note (a live hit between its hits leaves it) */
    int8_t key_nt;               /* the note KEYS played or recorded last on this track (0 = C4): a new step's (§2) */
    uint32_t seq_pos;            /* samples into the current step */
    uint16_t seq_idx;
    uint32_t seq_cnt;            /* steps played since PLAY: swing pairs follow it, so any length stays on the bar */
    uint8_t seq_rem;             /* the step length's remainder carried to the next step (seq.c div_period) */
    uint8_t seq_par;             /* the swing pairs' phase: a song's row keeps them on the bar (song.c) */
    uint8_t rskip, rskip_idx;    /* live recording put a hit into the step about to play: skip it once */
    uint32_t rng;                /* PROB: the track's random sequence (LCG), seeded at PLAY */
    uint32_t rat_len;            /* RATCH: the playing roll's step length (samples) */
    uint8_t rat_n, rat_k, rat_vel;   /* its hits, the next hit, their velocity; rat_n 0 = no roll */
    int32_t rat_off;             /* MICRO: where the roll's first hit was, in the playing step's samples (0 unnudged;
                                  * an early hit's < 0 once its own step plays) */
    uint8_t mic, mic_idx;        /* MICRO (seq.c): MIC_DUE the playing step's late hit is to come, MIC_EARLY step
                                  * mic_idx's early hit has played (the step before it playing) */
    uint16_t gfade;              /* M3 ghost key: how silenced the COMP source's sound is (0 heard .. 32767 muted) */
    lfo_state_t lfo[2];          /* LFO 1 / 2 runtime (lfo.c) */
    reson_t rs;                  /* RESON runtime (reson.c) */
    int32_t rfine;               /* RESON fine pitch from the LFOs (R.TUN), 1/256 semitone (lfo.c) */
    uint32_t lrng;               /* random generator of S&H / WANDER / RWALK, reseeded at PLAY */
    uint8_t lon, lnum, lpid[4];  /* the LFOs on (bit l), the knobs written this block (at most the 4 DEST slots'), which */
    int16_t lsave[4], lval[4];   /* their set values (restored at the end of the block), the modulated values */
    /* mix runtime (fx.c) */
    int32_t peak;
    int32_t dist_hp, dist_lp1, dist_lp2;   /* DIST insert state */
    uint8_t tail;                /* blocks to mix after the last voice (the DIST tail) */
    int32_t fs[2];               /* FILTER (filter.c): the SVF's states */
    int32_t fenv;                /* its envelope, Q24 (a hit: 1 << 24) */
    uint8_t fvel, fmode, fring;  /* the hit's velocity, the TYPE running (a change: from silence), ringing */
    int32_t srr_h, srr_a;        /* SRR (insert.c track_srr): the held sample, what is left of it (Q8 samples) */
    int32_t wow;                 /* ACID: the accent smoother, Q24 (accented notes charge it, track_render decays it
                                  * every block: it carries over consecutive accents, as the 303's) */
    uint16_t pre;                /* presets.c: the preset id the voice was loaded from (PRE_NONE: none; projects: FDRD) */
    uint8_t pre_ed;              /* .. a SOUND knob moved since (preset_touch) */
} track_t;

typedef struct {
    int16_t g[G_COUNT];
    uint8_t playing, seq_mode;
    uint8_t rec;                 /* live recording armed: bit per track */
    uint8_t sel;                 /* selected track 0..NTRK-1: keys, pages, editor */
    int8_t octave;               /* KEYS: the keyboard's octave, -2..+2 (OCT- / OCT+), never stored */
    uint32_t tick;               /* blocks since play */
    uint32_t cpu_q8;             /* audio ISR load, 1/256 */
    uint32_t cpu_rem;            /* its average's remainder (audio.c) */
    uint32_t sheds;              /* overload sheds (audio.c shed_voice): the top bar's CPU icon (ui_draw.c) */
    uint32_t master_q12;
    int32_t batt_raw;            /* smoothed ADC ch3 (battery divider), 0 = not read yet */
    int16_t act[6];              /* TOOLS action knobs CLR* INIT* (G_CLRALL ..): GO buttons, never stored; MUTE: a
                                  * copy of settings.mutebar; METRO: of fx_metro; THRU: of midi_thru; QUANT: of
                                  * rec_quant */
    uint8_t mute_q;              /* mutes to flip on the next bar (bit per track; seq.c) */
    uint8_t solo;                /* SOLO (the SMC-Mixer): bit per track, runtime only (trk_silent) */
    uint8_t lfo_in;              /* lfo.c: inside an audio block, between lfo_apply and lfo_restore */
    uint8_t lslot;               /* the LFO DEST page's slot 0..3 (KNOB 1): screen state, never stored */
} song_t;

static track_t trk[NTRK];
static song_t song;
#define TSEL (&trk[song.sel])    /* the selected track */
#define RING_PUBLISH() __asm__ volatile("" ::: "memory")   /* slot store before the index update */
static volatile uint32_t fm1_ms;  /* milliseconds since boot (TIMER4-based, TIMER5 ISR in main.c) */
/* boot-loop guard (main.c): two boots in a row that die in the first 30 s -> UBOOT */
#define BOOTGUARD_MAGIC 0x42475244u
struct { uint32_t magic, failed, pending; } bootguard __attribute__((section(".noinit")));
