/* SPDX-License-Identifier: GPL-3.0-only
 * Drum machine fork: 2026 DEADACTIVE */
/* The web editor's backup / restore (firmware/src/editor_backup.c; web/EDITOR_PROTOCOL.md 2.5 / 2.6): every reply and
 * refusal, backups = flash bytes, restore staging / commit / abort / timeout / update drop, a power cut at every erase /
 * program of a project restore, a project restored into another slot. The firmware's real project.c and storage.c on a
 * host flash (tests/flash_host.h), ASan + UBSan. editor.c is not here: a test-only stand-in for its framing API
 * (editor_proto.h) records the one reply each request gets. */
#define FELUCCA_FLASH 1
#include <stdint.h>
static uint8_t hflash[0x100000];
#define SMP_USER_XIP(k) ((const uint8_t *)hflash + 0xA0000u + (k) * 0x14000u)
#define VAR_XIP(off) ((const void *)(hflash + (off)))
#define ED_RESTORE_LOCK 1                             /* (ui.c asks editor_backup.c, as felucca.c builds it) */
#include "ui_host.h"
static uint32_t host_ms;
#define EDB_MS() host_ms
#include "../firmware/src/editor_proto.h"

/* ---- editor.c's framing API, test-only: one reply buffer */
static uint8_t erp[ED_REPLY_MAX + 16];
static uint32_t rp_n, rp_sends, rp_i, q_seq;
static void ed_put(uint32_t b)
{
    if (rp_n < sizeof erp)
        erp[rp_n++] = (uint8_t)b;
}
static void ed_reply(uint32_t cmd, uint32_t rc)
{
    rp_n = 0;
    ed_put(0xF0);
    ed_put(ED_H0);
    ed_put(ED_H1);
    ed_put(ED_H2);
    ed_put(cmd);
    ed_put(q_seq);
    ed_put(rc);
}
static void ed_push(uint32_t cmd) { ed_reply(cmd, 0); rp_n--; }
static void ed_b(uint32_t v) { ed_put(v & 127u); }
static void ed_u14(uint32_t v) { ed_put(v & 127u); ed_put((v >> 7) & 127u); }
static void ed_v14(int32_t v) { ed_u14((uint32_t)(v + 8192)); }
static void ed_u35(uint32_t v)
{
    uint32_t i;
    for (i = 0; i < 5u; i++)
        ed_put((v >> (7u * i)) & 127u);
}
static void ed_str(const char *s)
{
    while (*s)
        ed_put((uint8_t)*s++);
    ed_put(0);
}
static void pack7(void (*put)(uint32_t), const uint8_t *d, uint32_t n)
{
    uint32_t i, j, k;
    for (i = 0; i < n; i += 7u) {
        uint32_t hb = 0;
        k = n - i < 7u ? n - i : 7u;
        for (j = 0; j < k; j++)
            hb |= (uint32_t)(d[i + j] >> 7) << j;
        put(hb);
        for (j = 0; j < k; j++)
            put(d[i + j] & 127u);
    }
}
static void ed_pack(const void *d, uint32_t n) { pack7(ed_put, d, n); }
static int ed_restoring(void);
static void ed_state(void)
{
    uint32_t i;
    for (i = 0; i < ED_STATE_N; i++)
        ed_put(i == 6u ? (ed_restoring() ? ED_SF_RESTORING : 0u) : 0u);
}
static uint32_t ed_room(void) { return ED_REPLY_MAX - 1u - rp_n; }
static void ed_send(void)
{
    ed_put(0xF7);
    rp_sends++;
}
static void ed_fail(uint32_t cmd, uint32_t rc, uint32_t detail, const char *msg)
{
    ed_reply(cmd, rc);
    ed_b(detail);
    ed_str(msg);
    ed_send();
}
static uint32_t ed_get_u14(const uint8_t *a) { return a[0] | (uint32_t)a[1] << 7; }
static int32_t ed_get_v14(const uint8_t *a) { return (int32_t)ed_get_u14(a) - 8192; }
static uint32_t ed_get_u35(const uint8_t *a)
{
    return a[0] | (uint32_t)a[1] << 7 | (uint32_t)a[2] << 14 | (uint32_t)a[3] << 21 | (uint32_t)a[4] << 28;
}
static uint32_t ed_unpack7(const uint8_t *in, uint32_t n, uint8_t *out, uint32_t max)
{
    uint32_t i = 0, o = 0, j, k, hb;
    while (i < n) {
        hb = in[i++];
        k = n - i < 7u ? n - i : 7u;
        if (!k || hb > 127u)
            return 0;
        for (j = 0; j < k; j++) {
            if (o >= max || in[i + j] > 127u)
                return 0;
            out[o++] = (uint8_t)(in[i + j] | ((hb >> j) & 1u) << 7);
        }
        i += k;
    }
    return o;
}
#include "../firmware/src/editor_backup.c"

static int fails;
static void check(const char *what, int ok)
{
    printf("%s  %s\n", ok ? "ok  " : "FAIL", what);
    fails += !ok;
}

/* ---- requests */
static uint8_t ra[ED_REQ_MAX];
static uint32_t ra_n, rc_detail;
static void a_put(uint32_t b) { ra[ra_n++] = (uint8_t)b; }
static void a_u14(uint32_t v) { a_put(v & 127u); a_put((v >> 7) & 127u); }
static void a_u35(uint32_t v)
{
    uint32_t i;
    for (i = 0; i < 5u; i++)
        a_put((v >> (7u * i)) & 127u);
}
/* one request: its rc (0x100: not exactly one well-formed reply with this cmd and seq); rc_detail its detail */
static uint32_t req(uint32_t cmd)
{
    int h;
    q_seq = (q_seq + 1u) % 127u;
    rp_n = rp_sends = 0;
    h = ed_backup_cmd(cmd, ra, ra_n);
    ra_n = 0;
    if (!h || rp_sends != 1u || rp_n < 8u || rp_n > ED_REPLY_MAX || erp[4] != cmd || erp[5] != q_seq ||
        erp[rp_n - 1u] != 0xF7)
        return 0x100;
    rp_i = 7;
    rc_detail = erp[6] ? erp[7] : 0u;
    return erp[6];
}
static uint32_t r_b(void) { return erp[rp_i++]; }
static uint32_t r_u14(void) { rp_i += 2; return ed_get_u14(erp + rp_i - 2); }
static uint32_t r_u35(void) { rp_i += 5; return ed_get_u35(erp + rp_i - 5); }

static struct { uint32_t present, size, crc, seq, flags; } L[ED_OBJ_N];
static uint32_t list(void)
{
    uint32_t i, rc = req(ED_BACKUP_LIST);
    if (rc || r_b() != ED_OBJ_N)
        return rc ? rc : 0x101;
    for (i = 0; i < ED_OBJ_N; i++) {
        if (r_b() != i)
            return 0x102;
        L[i].present = r_b();
        L[i].size = r_u14();
        L[i].crc = r_u35();
        L[i].seq = r_u35();
        L[i].flags = r_b();
    }
    return rp_i + 1u == rp_n ? 0u : 0x103;
}
static int backup(uint32_t obj, uint8_t *out)       /* a whole object through LIST + GET; its size, -1 failed */
{
    uint32_t off, len;
    if (list() || !L[obj].present)
        return -1;
    for (off = 0; off < L[obj].size; off += ED_PIECE) {
        a_put(obj);
        a_u14(off);
        a_u35(L[obj].seq);
        if (req(ED_BACKUP_GET) || r_b() != obj || r_u14() != off)
            return -1;
        len = r_u14();
        if (len != (L[obj].size - off < ED_PIECE ? L[obj].size - off : ED_PIECE) ||
            ed_unpack7(erp + rp_i, rp_n - 1u - rp_i, out + off, ED_PIECE) != len)
            return -1;
    }
    return st_crc32(out, L[obj].size) == L[obj].crc ? (int)L[obj].size : -1;
}

/* a restore: BEGIN, the parts' pieces (up to `pieces` of them in all), COMMIT (commit 0: not sent). The first rc that
 * is not 0, else 0 */
typedef struct { const uint8_t *d[3]; uint32_t n[3], crc[3]; } robj_t;
static uint32_t rs_begin(uint32_t kind, uint32_t slot, const robj_t *o)
{
    uint32_t i, m;
    memcpy(&m, o->d[0], 4);
    a_put(ED_RS_BEGIN);
    a_put(kind);
    a_put(slot);
    a_u35(m);
    for (i = 0; i < 3u; i++) {
        a_u14(o->n[i]);
        a_u35(o->crc[i]);
    }
    return req(ED_RESTORE);
}
static uint32_t rs_piece(uint32_t part, uint32_t off, const uint8_t *d, uint32_t len)
{
    a_put(ED_RS_DATA);
    a_put(part);
    a_u14(off);
    pack7(a_put, d, len);
    return req(ED_RESTORE);
}
static uint32_t rs_op(uint32_t op)
{
    a_put(op);
    return req(ED_RESTORE);
}
static uint32_t restore(uint32_t kind, uint32_t slot, const robj_t *o, uint32_t pieces, int commit)
{
    uint32_t p, off, rc = rs_begin(kind, slot, o);
    for (p = 0; !rc && p < 3u; p++)
        for (off = 0; !rc && off < o->n[p] && pieces; off += ED_PIECE, pieces--)
            rc = rs_piece(p, off, o->d[p] + off, o->n[p] - off < ED_PIECE ? o->n[p] - off : ED_PIECE);
    return rc || !commit ? rc : rs_op(ED_RS_COMMIT);
}

/* ---- fixtures */
static step_t VS[NTRK][NSTEP];
static int16_t VTM[NTRK][4];
static const step_t *VSP[NTRK];
static void wipe_ram(void)                            /* a power cycle's RAM */
{
    memset(&mo, 0, sizeof mo);
    memset(proj_slot, 0, sizeof proj_slot);
    memset(lk_slot, 0, sizeof lk_slot);
    memset(var_buf, 0, sizeof var_buf);
    memset(var_who, 0, sizeof var_who);
    memset(&edb, 0, sizeof edb);
    var_play = 0;
    var_dirty = 0;
    var_lost = 0;
    lk_lost = 0;
    persist_note = 0;
}
static void power_cycle(void)
{
    wipe_ram();
    host_init();
    memset(&ui, 0, sizeof ui);
    transport_req = 0;
    persist_boot();
}
static void fresh(void)
{
    memset(hflash, 0xFF, sizeof hflash);
    power_cycle();
}
/* a project in slot s (SAVE): steps, a knob, two locks, variation 3 */
static void make_project(uint32_t s, uint32_t seed)
{
    uint32_t k, i;
    for (k = 0; k < NTRK; k++) {
        for (i = 0; i < NSTEP; i++) {
            memset(&trk[k].step[i], 0, sizeof trk[k].step[i]);
            trk[k].step[i].on = (i + k * 3u + seed) % 5u == 0u || (k == 0u && i % 4u == 0u);
            VS[k][i] = trk[k].step[i];
            VS[k][i].on = (i * 3u + k + seed) % 7u == 0u;
            VS[k][i].nt = (int8_t)(seed % 12u);
        }
        VTM[k][0] = (int16_t)(16u + (seed + k) % 48u);
        VTM[k][1] = (int16_t)(seed % 10u);
        VTM[k][2] = (int16_t)(seed * 7u % 101u);
        VTM[k][3] = 0;
        VSP[k] = VS[k];
    }
    trk[0].p[P_E1] = (int16_t)(seed % 40u);
    memset(&mo.b, 0, sizeof mo.b);
    lk_put(&mo.b, lk_key(1, 4, P_E1), (int32_t)(seed % 100u), 1);
    lk_put(&mo.b, lk_key(2, 8, P_E1), 20, 0);
    project_save(s);
    var_put(&var_buf[var_play], 2, VSP, VTM);
    project_save(s);
}
static uint8_t B[3][4096];                            /* a backed-up project's objects */
static robj_t backup_project(uint32_t s, uint8_t (*b)[4096])
{
    robj_t o;
    uint32_t p;
    int n;
    memset(&o, 0, sizeof o);
    for (p = 0; p < 3u; p++) {
        n = backup(ED_OBJ_PROJECT + s + 4u * p, b[p]);
        o.d[p] = b[p];
        o.n[p] = n < 0 ? 0u : (uint32_t)n;
        o.crc[p] = n < 0 ? 0u : st_crc32(b[p], o.n[p]);
    }
    return o;
}
static int same_flash(const uint8_t *keep) { return !memcmp(keep, hflash, sizeof hflash); }

/* ---- tests */
static void t_list_get(void)
{
    static uint8_t buf[4096];
    static int16_t kv[P_COUNT];
    uint32_t ok = 1, obj, i;
    fresh();
    ok &= list() == 0;
    for (obj = 0; obj < ED_OBJ_N; obj++)
        ok &= !L[obj].present && !L[obj].size && !L[obj].flags;
    check("BACKUP_LIST, nothing saved: 13 objects, none present, one reply under 400 bytes", (int)ok);

    make_project(0, 5);
    kv[P_E0] = 33;
    upr_set(3, 2, kv);
    upr_write();
    ok = list() == 0 && rp_n <= ED_REPLY_MAX;
    ok &= L[0].present && L[0].size == ED_SZ_PRESETS && L[1].present && L[1].size == ED_SZ_PROJECT && L[5].present &&
          L[5].size == ED_SZ_LOCKS && L[9].present && L[9].size == proj_slot[0].var_len && !L[2].present &&
          !L[6].present && !L[10].present;
    for (obj = 0; obj < ED_OBJ_N; obj++)
        ok &= L[obj].flags == 0u;
    for (obj = 0; obj < ED_OBJ_N; obj++) {         /* the copy LIST named (by its seq): its bytes, its CRC */
        static const uint32_t SO[4] = {OBJ_UPRESET0 + 1u, OBJ_PROJECT0, OBJ_LOCKS0, OBJ_VAR0};
        uint32_t so = obj ? SO[1u + (obj - 1u) / 4u] + (obj - 1u) % 4u : SO[0], c, hit = 0;
        st_hdr_t h, hc;
        int n;
        if (!L[obj].present)
            continue;
        n = backup(obj, buf);
        for (c = 0; c < 2u; c++)
            if (!st_head(so, c, &h) && h.seq == L[obj].seq) {
                hit = 1;
                ok &= n == (int)h.len && !memcmp(buf, hflash + st_sector(so, c) + ST_PAYLOAD_OFF, h.len) &&
                      L[obj].crc == h.crc && st_crc32(buf, h.len) == h.crc;
                if (obj < ED_OBJ_LOCKS)                 /* (a record, the user bank: storage.c's current copy) */
                    ok &= st_current(so, &hc) == (int)c;
            }
        ok &= hit;
    }
    check("BACKUP_GET: every object's bytes = its flash copy's, its CRC-32 = the storage header's (and the bytes'), "
          "seq the copy's", (int)ok);

    memset(st_buf, 0xA5, sizeof st_buf);              /* (a queued cue's staging area) */
    ok = list() == 0 && backup(1, buf) == ED_SZ_PROJECT && backup(9, buf) > 0;
    for (i = 0; i < sizeof st_buf; i++)
        ok &= st_buf[i] == 0xA5u;
    check("backups read flash through XIP: st_buf (a staged cue) untouched", (int)ok);

    trk[3].step[9].on ^= 1u;                          /* a live edit of the loaded slot A */
    upr_pending = 1;
    ok = list() == 0 && (L[0].flags & ED_BF_UNSAVED) && (L[1].flags & ED_BF_UNSAVED) && (L[5].flags & ED_BF_UNSAVED) &&
         (L[9].flags & ED_BF_UNSAVED) && !(L[2].flags & ED_BF_UNSAVED);
    {
        st_hdr_t h;
        int n = backup(1, buf);
        st_current(OBJ_PROJECT0, &h);
        ok &= n == ED_SZ_PROJECT && !memcmp(buf, st_buf, h.len);
    }
    upr_pending = 0;
    trk[3].step[9].on ^= 1u;
    check("unsaved changes: flagged UNSAVED (the slot's three objects, the user bank), the backup is flash's", (int)ok);

    ok = list() == 0;
    a_put(13); a_u14(0); a_u35(L[1].seq);
    ok &= req(ED_BACKUP_GET) == ED_E_BAD && rc_detail == ED_D_RANGE;
    a_put(2); a_u14(0); a_u35(0);
    ok &= req(ED_BACKUP_GET) == ED_E_REFUSED && rc_detail == ED_D_NOT_PRESENT;
    a_put(1); a_u14(0); a_u35(L[1].seq + 1u);
    ok &= req(ED_BACKUP_GET) == ED_E_STALE && rc_detail == ED_D_CHANGED;
    a_put(1); a_u14(100); a_u35(L[1].seq);
    ok &= req(ED_BACKUP_GET) == ED_E_BAD && rc_detail == ED_D_RANGE;
    a_put(1); a_u14(ED_SZ_PROJECT + 256u); a_u35(L[1].seq);
    ok &= req(ED_BACKUP_GET) == ED_E_BAD && rc_detail == ED_D_RANGE;
    a_put(1); a_u14(0); a_u35(L[1].seq); ra_n--;
    ok &= req(ED_BACKUP_GET) == ED_E_BAD && rc_detail == ED_D_LENGTH;
    a_put(0);
    ok &= req(ED_BACKUP_LIST) == ED_E_BAD && rc_detail == ED_D_LENGTH;
    flash_ok = 0;
    ok &= req(ED_BACKUP_LIST) == ED_E_REFUSED && rc_detail == ED_D_NO_FLASH;
    flash_ok = 1;
    ok &= ed_backup_cmd(ED_INFO, ra, 0) == 0 && ed_backup_cmd(ED_TEXT, ra, 0) == 0;
    i = L[1].seq;
    trk[1].p[P_E2] = 7;
    project_save(0);                                  /* a SAVE between LIST and GET */
    a_put(1); a_u14(0); a_u35(i);
    ok &= req(ED_BACKUP_GET) == ED_E_STALE && rc_detail == ED_D_CHANGED;
    check("BACKUP_GET / LIST refusals: object out of range, not present, changed since LIST (a SAVE), bad offset, bad "
          "length, no flash; other commands are not this file's", (int)ok);
    {   /* pieces after an object's first reuse it (edb_get's cache): a SAVE in between is still seen */
        uint32_t obj, saves, seq, moved = 0;
        ok = 1;
        for (obj = 1; obj < ED_OBJ_N; obj += 4u)       /* A's record, lock bank, variations */
            for (saves = 1; saves <= 2u; saves++) {     /* 2: the copy piece 0 read is overwritten too */
                ok &= list() == 0 && L[obj].present;
                seq = L[obj].seq;
                a_put(obj); a_u14(0); a_u35(seq);
                ok &= req(ED_BACKUP_GET) == ED_OK;
                a_put(obj); a_u14(ED_PIECE); a_u35(seq);
                ok &= req(ED_BACKUP_GET) == ED_OK && edb.g_obj == obj + 1u;
                for (i = 0; i < saves; i++) {
                    trk[1].p[P_E2] = (int16_t)(trk[1].p[P_E2] + 1);
                    lk_put(&mo.b, lk_key(5, 9, P_E1), (int32_t)(30 + i), 1);
                    project_save(0);
                }
                ok &= list() == 0;                      /* the truth: did the object move? */
                a_put(obj); a_u14(ED_PIECE); a_u35(seq);
                if (L[obj].seq != seq) {
                    moved++;
                    ok &= req(ED_BACKUP_GET) == ED_E_STALE && rc_detail == ED_D_CHANGED;
                } else
                    ok &= req(ED_BACKUP_GET) == ED_OK;
            }
        check("BACKUP_GET: a piece after the first reuses its object, yet a SAVE (one, or two: the copy read overwritten) "
              "between pieces answers CHANGED (the record, the lock bank), and an object the SAVE left alone (the "
              "variations) reads on", (int)ok && moved == 4u);
    }

    {                                                 /* both copies of A's lock bank damaged */
        uint32_t c;
        for (c = 0; c < 2u; c++)
            hflash[st_sector(OBJ_LOCKS0, c) + ST_PAYLOAD_OFF + 9u] ^= 0x55u;
    }
    ok = list() == 0 && L[1].present && (L[1].flags & ED_BF_LOST) && !L[5].present && L[9].present;
    check("BACKUP_LIST: a record whose lock bank no flash copy holds is LOST, the bank not present", (int)ok);
}

static void t_restore_refusals(void)
{
    static uint8_t keep[sizeof hflash], bad[4096];
    robj_t o, x;
    uint32_t ok = 1, i;
    fresh();
    make_project(0, 5);
    o = backup_project(0, B);
    memcpy(keep, hflash, sizeof keep);
    ok &= o.n[0] == ED_SZ_PROJECT && o.n[1] == ED_SZ_LOCKS && o.n[2] >= ED_SZ_VARS_MIN;
    for (i = ED_RS_DATA; i <= ED_RS_ABORT; i++)
        ok &= rs_op(i) == ED_E_BAD && rc_detail == ED_D_NOT_RESTORING;
    ok &= rs_op(4) == ED_E_BAD && rc_detail == ED_D_RANGE;
    ok &= req(ED_RESTORE) == ED_E_BAD && rc_detail == ED_D_LENGTH;
    check("RESTORE DATA / COMMIT / ABORT without BEGIN: rc 1 detail 41; an unknown op, no op: rc 1", (int)ok);

    transport_req = 1;                                /* PLAY */
    ok = rs_begin(ED_RK_PROJECT, 1, &o) == ED_E_STOP && rc_detail == ED_D_STOP && !ed_restoring() &&
         same_flash(keep);
    transport_req = 0;
    song.playing = 1;
    ok &= rs_begin(ED_RK_PRESETS, 0, &o) == ED_E_STOP && !ed_restoring();
    song.playing = 0;
    check("RESTORE BEGIN while playing: rc 3 STOP FIRST, nothing staged, flash untouched", (int)ok);

    ok = 1;
    a_put(ED_RS_BEGIN);
    for (i = 1; i < ED_LEN_RESTORE_BEGIN - 1u; i++)
        a_put(0);
    ok &= req(ED_RESTORE) == ED_E_BAD && rc_detail == ED_D_LENGTH;
    ok &= rs_begin(2, 0, &o) == ED_E_BAD && rc_detail == ED_D_RANGE;
    ok &= rs_begin(ED_RK_PROJECT, 4, &o) == ED_E_BAD && rc_detail == ED_D_RANGE;
    ok &= rs_begin(ED_RK_PRESETS, 1, &o) == ED_E_BAD && rc_detail == ED_D_RANGE;
    ok &= rs_begin(ED_RK_PRESETS, 0, &o) == ED_E_REFUSED && rc_detail == ED_D_BAD_OBJECT;   /* (a project's magic) */
    memcpy(bad, B[0], sizeof bad);
    x = o;
    x.d[0] = bad;
    memcpy(bad, "FDRH", 4);
    ok &= rs_begin(ED_RK_PROJECT, 1, &x) == ED_E_REFUSED && rc_detail == ED_D_NEWER;
    memcpy(bad, "FUN3", 4);
    ok &= rs_begin(ED_RK_PROJECT, 1, &x) == ED_E_REFUSED && rc_detail == ED_D_BAD_OBJECT;
    memcpy(bad, "FDRE", 4);                           /* an older record: alone */
    ok &= rs_begin(ED_RK_PROJECT, 1, &x) == ED_E_REFUSED && rc_detail == ED_D_BAD_OBJECT;
    x = o;
    x.n[0]--;
    ok &= rs_begin(ED_RK_PROJECT, 1, &x) == ED_E_REFUSED && rc_detail == ED_D_BAD_OBJECT;
    x = o;
    x.n[1] = 3000;
    ok &= rs_begin(ED_RK_PROJECT, 1, &x) == ED_E_REFUSED && rc_detail == ED_D_BAD_OBJECT;
    x = o;
    x.n[2] = ED_SZ_VARS_MIN - 1u;
    ok &= rs_begin(ED_RK_PROJECT, 1, &x) == ED_E_REFUSED && rc_detail == ED_D_BAD_OBJECT;
    x.n[2] = ED_SZ_VARS_MAX + 1u;
    ok &= rs_begin(ED_RK_PROJECT, 1, &x) == ED_E_REFUSED && rc_detail == ED_D_BAD_OBJECT;
    lk_blocked = 1;
    ok &= rs_begin(ED_RK_PROJECT, 1, &o) == ED_E_REFUSED && rc_detail == ED_D_BLOCKED;
    lk_blocked = 0;
    var_who[var_play ^ 1u] = 3;                       /* the park: C's unsaved variations */
    var_dirty |= 4u;
    ok &= rs_begin(ED_RK_PROJECT, 1, &o) == ED_E_REFUSED && rc_detail == ED_D_CUE_PARK + 2u;
    var_who[var_play ^ 1u] = 0;
    var_dirty &= (uint8_t)~4u;
    ok &= !ed_restoring() && same_flash(keep);
    check("RESTORE BEGIN refusals: length, kind / slot range, wrong magic or sizes (an older record with parts), a newer "
          "record (UPDATE THE FM-1 FIRST), USR3 guard, the park holding another slot's unsaved variations (SAVE C "
          "FIRST); nothing staged, flash untouched", (int)ok);

    ok = rs_begin(ED_RK_PROJECT, 1, &o) == ED_OK && r_b() == ED_RS_BEGIN && r_b() == ED_RK_PROJECT && r_b() == 1u &&
         ed_restoring() && str_eq(ui.msg, "RESTORING");
    ok &= rs_piece(ED_PART_LOCKS, 256, B[1] + 256, 256) == ED_E_STALE && rc_detail == ED_D_ORDER;
    ok &= rs_piece(3, 0, B[1], 256) == ED_E_BAD && rc_detail == ED_D_RANGE;
    ok &= rs_piece(ED_PART_LOCKS, 0, B[1], 255) == ED_E_BAD && rc_detail == ED_D_LENGTH;
    ok &= rs_piece(ED_PART_RECORD, 0, B[0], 256) == ED_OK && r_b() == ED_RS_DATA && r_b() == 0u && r_u14() == 0u &&
          r_u14() == 256u;
    ok &= rs_piece(ED_PART_RECORD, 0, B[0], 256) == ED_OK;   /* a retry of the last piece */
    ok &= rs_piece(ED_PART_RECORD, 512, B[0] + 512, 256) == ED_E_STALE && rc_detail == ED_D_ORDER;
    ok &= rs_op(ED_RS_COMMIT) == ED_E_REFUSED && rc_detail == ED_D_INCOMPLETE && ed_restoring();
    ok &= restore(ED_RK_PROJECT, 1, &o, 999, 0) == ED_OK;   /* (a BEGIN while one runs: that one dropped first) */
    transport_req = 1;
    ok &= rs_op(ED_RS_COMMIT) == ED_E_STOP && rc_detail == ED_D_STOP && ed_restoring() && same_flash(keep);
    transport_req = 0;
    ok &= rs_op(ED_RS_COMMIT) == ED_OK && r_b() == ED_RS_COMMIT && r_b() == ED_RK_PROJECT && r_b() == 1u &&
          erp[rp_i + 6u] == 0u && !ed_restoring();
    check("RESTORE BEGIN / DATA / COMMIT: replies; DATA out of order (rc 5 34), unknown part, wrong length, a retry "
          "accepted; COMMIT incomplete (rc 2 27, still restoring), playing (rc 3, flash untouched, still restoring), "
          "then stopped: written", (int)ok);

    memcpy(keep, hflash, sizeof keep);
    x = o;
    x.crc[1] ^= 1u;
    ok = restore(ED_RK_PROJECT, 2, &x, 999, 1) == ED_E_REFUSED && rc_detail == ED_D_CRC && !ed_restoring() &&
         same_flash(keep);
    memcpy(bad, B[0], ED_SZ_PROJECT);                 /* a record whose sum is wrong (the file's CRC right) */
    bad[100] ^= 1u;
    x = o;
    x.d[0] = bad;
    x.crc[0] = st_crc32(bad, ED_SZ_PROJECT);
    ok &= restore(ED_RK_PROJECT, 2, &x, 999, 1) == ED_E_REFUSED && rc_detail == ED_D_INVALID && !ed_restoring() &&
          same_flash(keep) && !proj_ok(&proj_slot[2]);
    x = o;                                            /* a record without its lock bank */
    x.n[1] = 0;
    ok &= restore(ED_RK_PROJECT, 2, &x, 999, 1) == ED_E_REFUSED && rc_detail == ED_D_INVALID && same_flash(keep);
    check("RESTORE COMMIT: a CRC mismatch (rc 2 25), a record failing the boot checks or missing its linked bank (rc 2 "
          "26): dropped, flash untouched", (int)ok);
}

static void t_abort_timeout_drop(void)
{
    static uint8_t keep[sizeof hflash];
    static project_t p1;
    static lk_bank_t l1;
    static upr_rec_t u;
    static int16_t kv[P_COUNT];
    robj_t o, pr;
    uint32_t ok;
    fresh();
    make_project(0, 5);
    o = backup_project(0, B);
    make_project(1, 8);                               /* B: the target, loaded */
    kv[P_E0] = 10;
    upr_set(0, 1, kv);
    upr_write();
    preset_user_boot();                               /* (its knobs as the boot clamps them) */
    memcpy(keep, hflash, sizeof keep);
    p1 = proj_slot[1];
    l1 = lk_slot[1];
    u = upr;
    memset(&pr, 0, sizeof pr);
    pr.d[0] = (const uint8_t *)&u;
    pr.n[0] = sizeof u;
    pr.crc[0] = st_crc32(&u, sizeof u) ^ 1u;

    ok = restore(ED_RK_PROJECT, 1, &o, 20, 0) == ED_OK && memcmp(&proj_slot[1], &p1, sizeof p1) &&
         rs_op(ED_RS_ABORT) == ED_OK && r_b() == ED_RS_ABORT && !ed_restoring() &&
         !memcmp(&proj_slot[1], &p1, sizeof p1) && !memcmp(&lk_slot[1], &l1, sizeof l1) && same_flash(keep);
    ok &= restore(ED_RK_PRESETS, 0, &pr, 2, 0) == ED_OK && rs_op(ED_RS_ABORT) == ED_OK &&
          !memcmp(&upr, &u, sizeof u) && same_flash(keep);
    check("RESTORE ABORT: the RAM homes (record, lock bank; the user bank) reloaded from flash, nothing written", (int)ok);

    ok = restore(ED_RK_PROJECT, 1, &o, 5, 0) == ED_OK;
    host_ms += ED_RESTORE_IDLE_MS;
    ui.msg_t = 0;
    ed_backup_poll();
    ok &= ed_restoring() && str_eq(ui.msg, "RESTORING");
    host_ms += 1u;
    ed_backup_poll();
    ok &= !ed_restoring() && !memcmp(&proj_slot[1], &p1, sizeof p1) && !memcmp(&lk_slot[1], &l1, sizeof l1) &&
          same_flash(keep) && rs_op(ED_RS_COMMIT) == ED_E_BAD && rc_detail == ED_D_NOT_RESTORING;
    ok &= restore(ED_RK_PRESETS, 0, &pr, 9, 0) == ED_OK;
    host_ms += ED_RESTORE_IDLE_MS + 1u;
    ed_backup_poll();
    ok &= !ed_restoring() && !memcmp(&upr, &u, sizeof u);
    check("RESTORE idle 3 s: aborted (RESTORING shown until then), homes reloaded from flash, nothing written", (int)ok);

    ok = restore(ED_RK_PROJECT, 1, &o, 999, 0) == ED_OK;
    ed_backup_drop();                                 /* update traffic (editor.c's silence rule) mid-restore */
    ok &= !ed_restoring() && rs_op(ED_RS_COMMIT) == ED_E_BAD && rc_detail == ED_D_NOT_RESTORING && same_flash(keep) &&
          !memcmp(&proj_slot[1], &p1, sizeof p1);
    ok &= restore(ED_RK_PROJECT, 1, &o, 999, 0) == ED_OK;
    usb.ota_req = 1;                                  /* the upgrade command waits at COMMIT */
    ok &= rs_op(ED_RS_COMMIT) == ED_E_BUSY && !ed_restoring() && same_flash(keep) &&
          !memcmp(&proj_slot[1], &p1, sizeof p1);
    usb.ota_req = 0;
    check("update abort mid-restore (ed_backup_drop, or the upgrade command at COMMIT): nothing committed, homes "
          "reloaded", (int)ok);
}

/* RESTORING on the device (ui.c ui_locked asks ed_restoring = edb.on): its own PLAY, cue keys, LOAD, SAVE, PASTE, NAME
 * and preset save / delete are refused with "RESTORING" and touch nothing (the staged homes, flash, the transport);
 * COMMIT, ABORT, the idle timeout and update traffic release them */
static int keys_refused(const uint8_t *keep, const project_t *staged)
{
    uint32_t ok = 1, ld = (uint32_t)proj_loaded(), vc = var_cur;
    transport_req = 0;
    ui.msg[0] = 0;
    play_press();
    ok &= transport_req == 0u && str_eq(ui.msg, "RESTORING");
    ui.msg[0] = 0;
    cue_keys(1u << STEP_KEY[0] | 1u << CUE_BK[3]);
    ok &= !cue.q_slot && !cue.q_var && proj_loaded() == (int32_t)ld && var_cur == vc && str_eq(ui.msg, "RESTORING");
    project_load(0);
    proj_load_from(0);
    project_save(ld);
    project_save_go(ld);
    project_paste(2);
    project_rename(ld, "X");
    ok &= preset_user_save(0, &trk[0]) < 0;
    preset_user_delete(0);
    ok &= !ui.confirm && proj_loaded() == (int32_t)ld && same_flash(keep) && transport_req == 0u &&
          !memcmp(&proj_slot[1], staged, sizeof *staged) && str_eq(ui.msg, "RESTORING");
    return (int)ok;
}
/* the live steps edited on the device while a restore runs (seqtools: the TOOLS screen, a held step's KNOB 1-4, live
 * recording with QUANT): refused (RESTORING) / nothing recorded; the copies still work. edit 1: no restore, they edit */
static step_t tl_keep[NTRK][NSTEP];
static int tools_edit(int edit)
{
    uint32_t ok = 1, k, s = song.sel;
    for (k = 0; k < NTRK; k++)
        memcpy(tl_keep[k], trk[k].step, sizeof tl_keep[k]);
    memset(&tl, 0, sizeof tl);
    ui.msg[0] = 0;
    ui.confirm = 0;
    ui.bank = 0;
    trk[s].p[P_SLEN] = 16;
    trk[s].p[P_SRC] = 0;
    trk[s].step[1].on = 1;
    trk[s].step[1].micro = 9;
    memcpy(tl_keep[s], trk[s].step, sizeof tl_keep[s]);
    fm1_in.notes = 1u << TL_K_CPSTEP;                   /* COPY STEP + step 2, COPY PAGE: the buffers (allowed) */
    tl_keys(1u << STEP_KEY[1]);
    fm1_in.notes = 0;
    tl_keys(1u << TL_K_CPPAGE);
    ok &= tl.st_ok && tl.st.micro == 9 && tl.cn == 16u;
    fm1_in.notes = 1u << TL_K_PSTEP;                    /* PASTE STEP + step 6, REPLACE, FILL, DUPLICATE, CLEAR */
    tl_keys(1u << STEP_KEY[5]);
    fm1_in.notes = 0;
    ok &= (trk[s].step[5].micro == 9) == edit;
    tl_keys(1u << TL_K_REPL | 1u << TL_K_FILL | 1u << TL_K_DUP);
    ok &= !ui.confirm || edit;
    ui.confirm = 0;
    tl_keys(1u << TL_K_CLEAR);
    ok &= edit ? ui.confirm == 1u : !ui.confirm && str_eq(ui.msg, "RESTORING");
    ui.confirm = 0;
    ui.held = 2;                                        /* step 3 held, KNOB 4 (NUDGE) turned */
    ui.step_t0[2] = 1;
    ui.step_si[2] = 2;
    ok &= step_edit(3u, 4) == 1 && (trk[s].step[2].micro != 0) == edit;
    ui.step_t0[2] = 0;
    song.rec = (uint8_t)(1u << s);                       /* armed, playing: a hit (QUANT's live record) */
    song.playing = 1;
    memset(trk[s].step, 0, sizeof trk[s].step);
    memcpy(tl_keep[s], trk[s].step, sizeof tl_keep[s]);
    input_hit(&trk[s], 100u);
    ok &= (memcmp(trk[s].step, tl_keep[s], sizeof tl_keep[s]) != 0) == edit;   /* (recorded: a step on) */
    song.playing = 0;
    song.rec = 0;
    if (edit)
        ok &= trk[s].p[P_SLEN] == 32;
    else
        for (k = 0; k < NTRK; k++)
            ok &= !memcmp(trk[k].step, tl_keep[k], sizeof tl_keep[k]) && trk[k].p[P_SLEN] == (k == s ? 16 : trk[k].p[P_SLEN]);
    return (int)ok;
}
static int keys_free(void)
{
    transport_req = 0;
    ui.msg[0] = 0;
    play_press();
    return !ed_restoring() && transport_req == 1u && !str_eq(ui.msg, "RESTORING");
}
static void t_restoring_lock(void)
{
    static uint8_t keep[sizeof hflash];
    static project_t staged;
    static int16_t kv[P_COUNT];
    robj_t o;
    uint32_t ok;
    fresh();
    make_project(0, 5);
    o = backup_project(0, B);
    make_project(1, 8);                               /* B: the target, loaded */
    kv[P_E0] = 10;
    upr_set(0, 1, kv);
    upr_write();
    ok = keys_free();
    transport_req = 0;
    memcpy(keep, hflash, sizeof keep);
    ok &= restore(ED_RK_PROJECT, 1, &o, 3, 0) == ED_OK && ed_restoring() && ui_locked();
    staged = proj_slot[1];
    ok &= keys_refused(keep, &staged) && ed_restoring();
    ok &= rs_op(ED_RS_ABORT) == ED_OK && keys_free();
    check("RESTORING: the device's PLAY, cue keys, LOAD, SAVE, PASTE, NAME, preset save / delete refused with its "
          "message, nothing touched; ABORT releases them", (int)ok);

    transport_req = 0;
    ok = restore(ED_RK_PROJECT, 1, &o, 3, 0) == ED_OK && ed_restoring();
    staged = proj_slot[1];
    ok &= tools_edit(0) && ed_restoring() && !memcmp(&proj_slot[1], &staged, sizeof staged) && same_flash(keep);
    ok &= rs_op(ED_RS_ABORT) == ED_OK && tools_edit(1);
    transport_req = 0;
    check("RESTORING: the TOOLS screen's pastes, DUPLICATE and CLEAR, a held step's KNOB 1-4 refused (RESTORING), live "
          "recording records nothing, the copies work; after the restore they edit again", (int)ok);

    transport_req = 0;
    ok = restore(ED_RK_PROJECT, 1, &o, 3, 0) == ED_OK;
    staged = proj_slot[1];
    ok &= keys_refused(keep, &staged);
    host_ms += ED_RESTORE_IDLE_MS + 1u;
    ed_backup_poll();
    ok &= keys_free();
    transport_req = 0;
    ok &= restore(ED_RK_PROJECT, 1, &o, 3, 0) == ED_OK && ed_restoring() && ui_locked();
    ed_backup_drop();                                 /* update traffic */
    ok &= keys_free();
    transport_req = 0;
    ok &= restore(ED_RK_PROJECT, 1, &o, 999, 1) == ED_OK && keys_free();
    transport_req = 0;
    check("RESTORING released by the idle timeout, update traffic and COMMIT", (int)ok);
}

static void t_other_slot_plays(void)
{
    static uint8_t C[3][4096];
    static project_t pa;
    static lk_bank_t la;
    static var_bank_t va;
    robj_t a, c;
    uint32_t ok, k, age, f;
    fresh();
    make_project(0, 5);
    a = backup_project(0, B);
    pa = proj_slot[0];
    la = lk_slot[0];
    va = var_buf[var_play];
    make_project(2, 11);
    c = backup_project(2, C);
    project_load(0);                                  /* (C not loaded) */
    ok = restore(ED_RK_PROJECT, 2, &a, 999, 1) == ED_OK && list() == 0 && L[3].present && L[7].present &&
         L[11].present && !L[3].flags;
    {
        static uint8_t b[4096];
        ok &= backup(7, b) == ED_SZ_LOCKS && b[4] == 2u && backup(11, b) == (int)a.n[2] && b[4] == 2u;
    }
    power_cycle();
    project_load(2);
    ok &= str_eq(ui.msg, "LOADED") && var_who[var_play] == 3u && mo.b.count == la.count &&
          !memcmp(mo.b.key, la.key, sizeof la.key) && !memcmp(mo.b.val, la.val, sizeof la.val) &&
          var_buf[var_play].used == va.used && !memcmp(var_buf[var_play].d, va.d, va.used) &&
          trk[0].p[P_E1] == pa.t[0].p[P_E1];
    for (k = 0; k < NTRK; k++)
        ok &= !memcmp(proj_slot[2].t[k].step, pa.t[k].step, sizeof pa.t[k].step);
    age = hit_age(&trk[0]);
    transport_req = 1;
    for (f = 0; f < 400u; f++)
        render_mix(0, 0, CTL);
    ok &= song.playing && hit_age(&trk[0]) != age;
    transport_req = 2;
    render_mix(0, 0, CTL);
    check("a project restored into another slot (A's backup into C): re-sealed for C, loads after a power cycle "
          "(steps, knobs, locks, variations as A's) and plays", (int)ok);

    trk[5].step[3].on ^= 1u;                          /* C loaded, with a live edit */
    ok = restore(ED_RK_PROJECT, 2, &c, 999, 1) == ED_OK && var_who[var_play] == 3u && !slot_dirty(2) &&
         str_eq(ui.msg, "LOADED");
    for (k = 0; k < NTRK; k++)
        ok &= !memcmp(trk[k].step, ((const project_t *)C[0])->t[k].step, sizeof trk[k].step);
    check("a restore into the loaded slot: loaded again as LOAD does (its live edits replaced)", (int)ok);
}

static void t_power_cut(void)
{
    static uint8_t keep[sizeof hflash];
    robj_t o;
    uint32_t n, i, ok = 1, olds = 0, news = 0, old_sum, new_sum;
    fresh();
    make_project(0, 5);
    o = backup_project(0, B);
    make_project(1, 8);                               /* the old project in B */
    old_sum = proj_slot[1].sum;
    memcpy(keep, hflash, sizeof keep);
    host_nflog = 0;
    ok &= restore(ED_RK_PROJECT, 1, &o, 999, 1) == ED_OK;
    n = host_nflog;
    new_sum = proj_slot[1].sum;
    for (i = 0; i <= n && ok; i++) {
        uint32_t rc;
        memcpy(hflash, keep, sizeof keep);
        power_cycle();
        host_fail_at = (int)i;                        /* the power goes at erase / program i of the commit */
        rc = restore(ED_RK_PROJECT, 1, &o, 999, 1);
        host_fail_at = -1;
        ok &= i < n ? rc == ED_E_FLASH && !ed_restoring() : rc == ED_OK;
        power_cycle();
        ok &= proj_ok(&proj_slot[1]) && !lk_lost && !var_lost && proj_var_flash(1) != 0 &&
              lk_slot[1].count == proj_slot[1].lk_n;
        if (proj_slot[1].sum == old_sum)
            olds++;
        else if (proj_slot[1].sum == new_sum)
            news++;
        else
            ok = 0;
        project_load(1);
        ok &= str_eq(ui.msg, "LOADED");
        if (!ok)
            printf("     cut at op %u of %u: rc %u msg %s lost %x %x\n", i, n, rc, ui.msg, lk_lost, var_lost);
    }
    check("a power cut at every erase / program of a project restore: the old or the new project loads whole (record, "
          "lock bank, variations)", ok && n > 20u && olds && news && host_fl_stray == 0);
}

static void t_presets(void)
{
    static upr_rec_t u, b;
    robj_t o;
    preset_t p;
    const int8_t *f;
    uint32_t ok, i;
    st_hdr_t h;
    fresh();
    memset(&u, 0, sizeof u);
    u.magic = UPR_MAGIC;
    u.s[0].used = UPR_USED | UPR_VOICE;              /* a voice-only slot (moved from UPR1) */
    u.s[0].model = 1;
    u.s[0].k[2] = 17;
    for (i = 0; i < UPR_NFX; i++)
        u.s[0].f[i] = (int8_t)TP[UPR_FX[i]].def;
    u.s[95].used = UPR_USED;                         /* the last slot, with its FX */
    u.s[95].model = NMODELS - 1u;
    for (i = 0; i < UPR_NFX; i++)
        u.s[95].f[i] = (int8_t)clamp(TP[UPR_FX[i]].min + 1, TP[UPR_FX[i]].min, TP[UPR_FX[i]].max);
    u.mv[3] = 1;                                     /* old slot 100 moved into slot 1 */
    memset(&o, 0, sizeof o);
    o.d[0] = (const uint8_t *)&u;
    o.n[0] = sizeof u;
    o.crc[0] = st_crc32(&u, sizeof u);
    ok = sizeof u == ED_SZ_PRESETS && ED_SZ_PRESETS == 3204u;
    ok &= restore(ED_RK_PRESETS, 0, &o, 999, 1) == ED_OK && r_b() == ED_RS_COMMIT && r_b() == ED_RK_PRESETS &&
          st_current(OBJ_UPRESET0 + 1u, &h) >= 0 && h.len == sizeof u && !memcmp(st_buf, &u, sizeof u) &&
          preset_get(PRE_NFACT + 0u, &p) && p.model == 1u && preset_get(PRE_NFACT + 95u, &p) &&
          !preset_get(PRE_NFACT + 1u, &p) && backup(0, (uint8_t *)&b) == (int)sizeof b && !memcmp(&b, &u, sizeof u);
    f = upr_fx(PRE_NFACT + 95u);
    ok &= f && !memcmp(f, u.s[95].f, UPR_NFX) && !upr_fx(PRE_NFACT + 0u) && upr.mv[3] == 1u &&
          preset_rec_dec_in(PRE_REC_USER | 99u, PRE_UID, PRE_NFACT) == PRE_NFACT + 0u;
    ok &= list() == 0 && L[0].present && L[0].size == ED_SZ_PRESETS;
    check("RESTORE user presets: the UPR2 record written as sent (a voice-only slot, a slot with FX, the moves), the "
          "user bank reloaded, listed, its backup = the bytes", (int)ok);
    u.s[4].used = 2;
    o.crc[0] = st_crc32(&u, sizeof u);
    ok = restore(ED_RK_PRESETS, 0, &o, 999, 1) == ED_E_REFUSED && rc_detail == ED_D_INVALID;
    u.s[4].used = 1;
    u.s[4].model = NMODELS;
    o.crc[0] = st_crc32(&u, sizeof u);
    ok &= restore(ED_RK_PRESETS, 0, &o, 999, 1) == ED_E_REFUSED && rc_detail == ED_D_INVALID;
    u.s[4].used = 0;
    u.s[4].model = 0;
    u.mv[5] = PRE_NUSER + 1u;
    o.crc[0] = st_crc32(&u, sizeof u);
    ok &= restore(ED_RK_PRESETS, 0, &o, 999, 1) == ED_E_REFUSED && rc_detail == ED_D_INVALID && !ed_restoring() &&
          upr.s[0].used == (UPR_USED | UPR_VOICE) && !upr.s[4].used && !upr.mv[5];
    check("RESTORE user presets refused: a slot neither used, voice only nor empty, a model past the table, a move "
          "past the bank (rc 2 26)", (int)ok);
    {                                                 /* an older UPR1 record: not this firmware's object */
        static uint8_t old[UPR1_SIZE];
        uint32_t m = UPR1_MAGIC;
        memset(old, 0, sizeof old);
        memcpy(old, &m, 4);
        memset(&o, 0, sizeof o);
        o.d[0] = old;
        o.n[0] = sizeof old;
        o.crc[0] = st_crc32(old, sizeof old);
        ok = restore(ED_RK_PRESETS, 0, &o, 999, 1) == ED_E_REFUSED && rc_detail == ED_D_BAD_OBJECT && !ed_restoring();
        check("RESTORE an older UPR1 record: refused (rc 2 24), the page converts it first", (int)ok);
    }
}

static void t_old_record(void)
{
    static project_t ve;
    robj_t o;
    uint32_t ok, k;
    fresh();
    make_project(0, 5);
    ve = proj_slot[0];                                /* as 0.23.x saved it: FDRE, no motion */
    ve.magic = PROJ_MAGIC_VE;
    memset((uint8_t *)&ve + __builtin_offsetof(project_t, lk_n), 0,
           __builtin_offsetof(project_t, song) - __builtin_offsetof(project_t, lk_n));
    ve.sum = proj_sum(&ve);
    memset(&o, 0, sizeof o);
    o.d[0] = (const uint8_t *)&ve;
    o.n[0] = sizeof ve;
    o.crc[0] = st_crc32(&ve, sizeof ve);
    ok = restore(ED_RK_PROJECT, 3, &o, 999, 1) == ED_OK && list() == 0 && L[4].present && (L[4].flags & ED_BF_OLD) &&
         !L[8].present && !L[12].present;
    power_cycle();
    project_load(3);
    ok &= str_eq(ui.msg, "LOADED") && mo.b.count == 0u;
    for (k = 0; k < NTRK; k++)
        ok &= !memcmp(trk[k].step, ve.t[k].step, sizeof ve.t[k].step);
    check("RESTORE an older record (FDRE): written as it is, listed OLD, converted at load as always", (int)ok);
}

/* an FDRF project (a file the editor made before NUDGE: the record links its lock bank and variations, steps 0..6's
 * spare bytes hold KEYF, SRR and the INSERT) restores into a FDRG device: written as it is, OLD, converted at load as
 * flash's FDRF records are (every NUDGE 0, the parameters kept, its locks and variations linked) */
static void t_fdrf_record(void)
{
    static project_t vf;
    static uint8_t F[3][4096];
    robj_t o;
    uint32_t ok, k, i;
    fresh();
    trk[1].p[P_SRR] = 40;
    trk[2].p[P_IMIX] = 10;
    trk[3].p[P_ITYPE] = 2;
    make_project(0, 5);
    o = backup_project(0, F);
    vf = *(const project_t *)F[0];
    ok = vf.magic == PROJ_MAGIC && vf.lk_n && vf.var_len;
    vf.magic = PROJ_MAGIC_VF;                          /* as the editor before NUDGE read it from 0.27.x / 0.28 */
    for (k = 0; k < NTRK; k++)
        for (i = 0; i < NSTEP; i++)
            vf.t[k].step[i].rsv = i < PROJ_XP ? vf.xp[k][i] : 0u;
    memset(vf.xp, 0, sizeof vf.xp);
    vf.sum = proj_sum(&vf);
    o.d[0] = (const uint8_t *)&vf;
    o.crc[0] = st_crc32(&vf, sizeof vf);
    ok &= restore(ED_RK_PROJECT, 3, &o, 999, 1) == ED_OK && list() == 0 && L[4].present && (L[4].flags & ED_BF_OLD) &&
          L[8].present && L[12].present && !(L[4].flags & ED_BF_LOST);
    power_cycle();
    project_load(3);
    ok &= str_eq(ui.msg, "LOADED") && mo.b.count == vf.lk_n && trk[1].p[P_SRR] == 40 && trk[2].p[P_IMIX] == 10 &&
          trk[3].p[P_ITYPE] == 2;
    for (k = 0; k < NTRK; k++)
        for (i = 0; i < NSTEP; i++)
            ok &= trk[k].step[i].micro == 0 && trk[k].step[i].on == vf.t[k].step[i].on;
    ok &= cue_var(2) == 0 && var_cur == 2u;            /* its variation 3 */
    for (k = 0; k < NTRK; k++)
        for (i = 0; i < NSTEP; i++)
            ok &= trk[k].step[i].on == VS[k][i].on;
    check("RESTORE an FDRF project (a file from the editor before NUDGE) with its lock bank and variations: written as "
          "it is, listed OLD, converted at load (NUDGE 0, KEYF / SRR / INSERT kept, locks and variations linked)", (int)ok);
}

/* the main-loop cost of a full backup, worst case (4 projects, every variation used, full lock banks): host
 * instructions (drum_host.h instr_now) of BACKUP_LIST and of each BACKUP_GET piece, the page's order. A piece after
 * an object's first reuses what the first worked out (edb_get's cache, checked by the storage heads): it must cost a
 * small part of a first piece. `editor_backup_test bench` prints the figures only. */
static void t_backup_cost(int print_only)
{
    static uint8_t out[4096];
    uint64_t a, c, list_c, first = 0, rest = 0, max_rest = 0, first_max = 0;
    uint32_t s, v, k, i, obj, off, nfirst = 0, nrest = 0, ok = 1, bytes = 0;
    static int16_t kv[P_COUNT];
    fresh();
    for (i = 0; i < PRE_NUSER; i++)                     /* the user presets saved */
        upr_set(i, 1, kv);
    upr_write();
    for (s = 0; s < 4u; s++) {
        make_project(s, 3u + s);
        memset(&mo.b, 0, sizeof mo.b);
        for (i = 0; i < 1000u; i++)                     /* a lock bank nearly full */
            lk_put(&mo.b, lk_key(i % NTRK, (i / NTRK) % NSTEP, P_E0 + i % 8u), (int32_t)(i % 100u), (int)(i & 1u));
        for (v = 1; v < VAR_N; v++) {                   /* every variation used */
            for (k = 0; k < NTRK; k++)
                for (i = 0; i < NSTEP; i++)
                    VS[k][i].on = (i + k + v + s) % 4u == 0u;
            var_put(&var_buf[var_play], v, VSP, VTM);
        }
        project_save(s);
    }
    a = instr_now();
    ok &= list() == 0u;
    list_c = instr_now() - a;
    for (obj = 0; obj < ED_OBJ_N; obj++) {
        if (!L[obj].present)
            continue;
        bytes += L[obj].size;
        for (off = 0; off < L[obj].size; off += ED_PIECE) {
            a_put(obj);
            a_u14(off);
            a_u35(L[obj].seq);
            a = instr_now();
            ok &= req(ED_BACKUP_GET) == 0u;
            c = instr_now() - a;
            ok &= ed_unpack7(erp + 12, rp_n - 13u, out + off, ED_PIECE) > 0u;
            if (!off) {
                first += c;
                nfirst++;
                first_max = c > first_max ? c : first_max;
            } else {
                rest += c;
                nrest++;
                max_rest = c > max_rest ? c : max_rest;
            }
        }
        ok &= st_crc32(out, L[obj].size) == L[obj].crc;
    }
    printf("cost  backup, worst case (%u B, %u pieces): BACKUP_LIST %llu host instructions; BACKUP_GET first pieces "
           "%llu on average (max %llu), the others %llu on average (max %llu); all pieces %llu\n", bytes,
           nfirst + nrest, (unsigned long long)list_c, (unsigned long long)(nfirst ? first / nfirst : 0),
           (unsigned long long)first_max, (unsigned long long)(nrest ? rest / nrest : 0),
           (unsigned long long)max_rest, (unsigned long long)(first + rest));
    if (print_only)
        return;
    check("backup cost: the 13 objects read whole (CRCs right); a piece after an object's first costs under a quarter "
          "of a first piece (it reuses its object, checked by the storage heads)",
          (int)ok && nfirst == ED_OBJ_N && nrest > 100u && (!instr_now() || max_rest * 4u < first / nfirst));
}

int main(int argc, char **argv)
{
    if (argc > 1 && !strcmp(argv[1], "bench")) {
        t_backup_cost(1);
        return 0;
    }
    t_backup_cost(0);
    t_list_get();
    t_restore_refusals();
    t_abort_timeout_drop();
    t_restoring_lock();
    t_other_slot_plays();
    t_power_cut();
    t_presets();
    t_old_record();
    t_fdrf_record();
    check("flash: no erase or program outside the map", host_fl_stray == 0);
    printf(fails ? "editor_backup_test: %d FAILED\n" : "editor_backup_test: all passed\n", fails);
    return fails ? 1 : 0;
}
