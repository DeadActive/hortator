/* WAV renders for listening: one file per model, the kit demo, the demo kits (808, 909, Plaits, mixed) and the
 * M2 demos (Grids map / Euclidean, PROB / RATCH).
 * drumsim OUTDIR */
#include "drum_host.h"
#include <sys/stat.h>

static void wav_hdr(FILE *f, uint32_t frames)
{
    uint32_t v;
    uint16_t a = 1, ch = 2, ba = 4, bits = 16;
    uint32_t sr = FS, br = FS * 4;
    fwrite("RIFF", 1, 4, f); v = 36 + frames * 4; fwrite(&v, 4, 1, f);
    fwrite("WAVEfmt ", 1, 8, f); v = 16; fwrite(&v, 4, 1, f);
    fwrite(&a, 2, 1, f); fwrite(&ch, 2, 1, f); fwrite(&sr, 4, 1, f); fwrite(&br, 4, 1, f);
    fwrite(&ba, 2, 1, f); fwrite(&bits, 2, 1, f);
    fwrite("data", 1, 4, f); v = frames * 4; fwrite(&v, 4, 1, f);
}

static void wav_put(FILE *f, int32_t l, int32_t r)
{
    int16_t s[2] = {(int16_t)clamp(l, -32768, 32767), (int16_t)clamp(r, -32768, 32767)};
    fwrite(s, 2, 2, f);
}

#define GAP (FS * 6 / 10 / CTL * CTL)
static int32_t L[GAP], R[GAP];

static void hit_and_write(FILE *f, track_t *t, uint32_t vel, uint32_t *frames)
{
    uint32_t i;
    drum_hit(t, vel);
    render_mix(L, R, GAP);
    for (i = 0; i < GAP; i++)
        wav_put(f, L[i], R[i]);
    *frames += GAP;
}

/* a demo kit: 8 tracks (model, TUNE, DECAY or -1 = the old default), a 16-step pattern ('x' hit, 'X' accent) per track,
 * played 4 bars at 120 BPM through the whole mix (FX sends on the snare, clap and hats), written to DIR/NAME */
typedef struct {
    const char *name;
    uint32_t model[NTRK];
    int16_t tune[NTRK], decay[NTRK];
    const char *pat[NTRK];
} demo_kit_t;

static const demo_kit_t KITS[] = {
    {"kit_808.wav", {DM_K808, DM_S808, DM_C808, DM_HATC, DM_HATO, DM_TOM, DM_COWB, DM_CYMB},
     {0, 0, 0, 0, 0, 0, 0, 0}, {-1, -1, -1, -1, -1, -1, -1, -1},
     {"X..x..x...x..x..", "....X.......X...", "....x.......x..x", "x.x.x.x.x.x.x.x.", "..x...x...x...x.",
      "..........x.x.xX", ".x.....x...x....", "X..............."}},
    {"kit_909.wav", {DM_K909, DM_S909, DM_C909, DM_HATC, DM_HATO, DM_RIM, DM_CLAVE, DM_CONGA},
     {0, 0, 0, 0, 0, 0, 0, 0}, {-1, -1, -1, -1, -1, -1, -1, -1},
     {"X...x...x...x...", "....X.......X..x", "....x.......x...", "xxxxxxxxxxxxxxXx", "..x...x...x...x.",
      "...x.....x....x.", ".x....x...x.....", "......x.x.....x."}},
    {"kit_plaits.wav", {DM_KBOOM, DM_SSNAP, DM_SCRAK, DM_HMETL, DM_HNOIS, DM_KPUNC, DM_KBOOM, DM_SSNAP},
     {0, 0, 0, 0, 0, 0, 12, 12}, {-1, -1, -1, -1, -1, 40, 30, 10},
     {"X..x..x...x..x..", "....X.......X...", "....x.......x..x", "x.x.x.x.x.x.x.x.", "..x...x...x...x.",
      "X.......X.......", "..........x.x.x.", ".x.....x...x...."}},
    {"kit_mix.wav", {DM_KBOOM, DM_S808, DM_SCRAK, DM_HATC, DM_HNOIS, DM_K909, DM_TOM, DM_CYMB},
     {0, 0, 0, 0, 0, 0, 0, 0}, {-1, -1, -1, -1, -1, -1, -1, -1},
     {"X...x...x...x...", "....X.......X...", "....x.......x..x", "x.x.x.x.x.x.x.x.", "..x...x...x...x.",
      "..x.......x..x..", "..........x.x.xX", "X..............."}},
};

static void write_kit(const char *dir, const demo_kit_t *kit)
{
    char path[256];
    uint32_t total = 4 * 16 * (FS * 60 / 120 / 4) / CTL * CTL, frames, i, k;
    FILE *f;
    snprintf(path, sizeof path, "%s/%s", dir, kit->name);
    f = fopen(path, "wb");
    wav_hdr(f, total);
    host_init();
    for (i = 0; i < NTRK; i++) {
        track_t *t = &trk[i];
        old_set_model(t, kit->model[i]);
        t->p[P_E0] = kit->tune[i];
        if (kit->decay[i] >= 0)
            t->p[P_E1] = kit->decay[i];
        for (k = 0; k < 16; k++) {
            t->step[k].on = kit->pat[i][k] != '.';
            t->step[k].acc = kit->pat[i][k] == 'X';
        }
    }
    trk[1].p[P_REV] = 40;
    trk[2].p[P_REV] = 50;
    trk[3].p[P_DLY] = 25;
    transport_req = 1;
    for (frames = 0; frames < total; frames += GAP < total - frames ? GAP : total - frames) {
        uint32_t n = GAP < total - frames ? GAP : total - frames;
        render_mix(L, R, n);
        for (i = 0; i < n; i++)
            wav_put(f, L[i], R[i]);
    }
    fclose(f);
    printf("drumsim: %s\n", path);
}

/* M2 demos, 120 BPM through the whole mix. grids_map.wav: kick / snare / hats on Grids MAP at four map points
 * (2 bars each, chaos off) then the same with chaos 100; grids_euclid.wav: EUCLID 16/12/8 then 5/7/3 (4 bars each);
 * prob_ratch.wav: a kit with 50 % hats, 3-hit rolls, a 1/2 and 2/2 snare fill and a 1-SHOT crash (8 bars) */
static void write_demo(const char *dir, const char *name, uint32_t bars, void (*bar)(uint32_t b))
{
    char path[256];
    uint32_t bar_len = 16 * (FS * 60 / 120 / 4), total = bars * bar_len / CTL * CTL, frames, i, b;
    FILE *f;
    snprintf(path, sizeof path, "%s/%s", dir, name);
    f = fopen(path, "wb");
    wav_hdr(f, total);
    transport_req = 1;
    for (b = 0, frames = 0; frames < total; b++) {
        uint32_t end = (b + 1) * bar_len / CTL * CTL < total ? (b + 1) * bar_len / CTL * CTL : total;
        bar(b);
        while (frames < end) {
            uint32_t n = GAP < end - frames ? GAP : end - frames;
            render_mix(L, R, n);
            for (i = 0; i < n; i++)
                wav_put(f, L[i], R[i]);
            frames += n;
        }
    }
    fclose(f);
    printf("drumsim: %s\n", path);
}

static void grids_kit(void)                          /* 808 kick / snare / closed hat on the three channels */
{
    host_init();
    old_set_model(&trk[0], DM_K808);
    old_set_model(&trk[1], DM_S808);
    old_set_model(&trk[2], DM_HATC);
    trk[0].p[P_SRC] = 1;
    trk[1].p[P_SRC] = 2;
    trk[2].p[P_SRC] = 3;
    trk[1].p[P_REV] = 40;
    song.g[G_GFILL1] = 80;
    song.g[G_GFILL2] = 70;
    song.g[G_GFILL3] = 100;
}

static void map_bar(uint32_t b)
{
    static const int16_t XY[4][2] = {{64, 64}, {0, 0}, {127, 30}, {30, 127}};
    song.g[G_GX] = XY[(b / 2u) % 4u][0];
    song.g[G_GY] = XY[(b / 2u) % 4u][1];
    song.g[G_GCHAOS] = b < 8u ? 0 : 100;
}

static void euclid_bar(uint32_t b)
{
    static const int16_t LN[2][3] = {{16, 12, 8}, {5, 7, 3}};
    uint32_t k;
    song.g[G_GMODE] = 1;
    for (k = 0; k < 3u; k++) {
        song.g[G_GLEN1 + k] = LN[b / 4u % 2u][k];
        song.g[G_GFILL1 + k] = (int16_t)(b / 4u ? 60 : 40);
    }
}

static void prob_bar(uint32_t b) { (void)b; }

static void prob_kit(void)
{
    uint32_t k;
    host_init();
    old_set_model(&trk[0], DM_K909);
    old_set_model(&trk[1], DM_S909);
    old_set_model(&trk[2], DM_HATC);
    old_set_model(&trk[3], DM_CYMB);
    for (k = 0; k < 16u; k += 4u)
        trk[0].step[k].on = 1;
    trk[1].step[4].on = trk[1].step[12].on = 1;
    trk[1].step[14].on = 1;
    trk[1].step[14].cond = 22;                       /* 1/2: a fill every other bar */
    trk[1].step[15].on = 1;
    trk[1].step[15].cond = 23;                       /* 2/2 */
    trk[1].step[15].rat = 2;
    for (k = 0; k < 16u; k++) {
        trk[2].step[k].on = 1;
        trk[2].step[k].cond = (uint8_t)((k & 1u) ? cond_store(10) : 0u);   /* off-beats 50 % */
    }
    trk[2].step[7].rat = 2;
    trk[2].step[15].rat = 3;
    trk[3].step[0].on = trk[3].step[0].acc = 1;
    trk[3].step[0].cond = COND_1SHOT;
    trk[1].p[P_REV] = 40;
}

/* M3: the same kit dry and pumping: T1 K909 four on the floor keys the compressor; open hats, toms and the snare's
 * reverb are ducked (4 bars each); then a REL sweep (100 ms .. 1 s over 4 bars) and MKUP at the limiter end */
static void pump_kit(int src, int rat, int mkup, int thr)
{
    uint32_t k;
    host_init();
    old_set_model(&trk[0], DM_K909);
    old_set_model(&trk[1], DM_S909);
    old_set_model(&trk[2], DM_HATO);
    old_set_model(&trk[3], DM_TOM);
    for (k = 0; k < 16u; k += 4u)
        trk[0].step[k].on = 1;
    trk[1].step[4].on = trk[1].step[12].on = 1;
    for (k = 2; k < 16u; k += 4u)
        trk[2].step[k].on = 1;
    trk[2].p[P_E1] = 110;                            /* long open hats: the pump is heard */
    trk[3].step[7].on = trk[3].step[15].on = 1;
    trk[1].p[P_REV] = 70;
    song.g[G_CSRC] = (int16_t)src;
    song.g[G_CRAT] = (int16_t)rat;
    song.g[G_CMKUP] = (int16_t)mkup;
    song.g[G_CTHR] = (int16_t)thr;
    trk[1].p[P_DUCK] = trk[2].p[P_DUCK] = trk[3].p[P_DUCK] = 1;
}

static void rel_bar(uint32_t b) { song.g[G_CREL] = (int16_t)(5 + b * 12); }

/* GHOST: the pump kit with the kick heard, then muted with KEEP (ghost), muted with MUTE (no pump), HIDE unmuted */
static void ghost_kit(int ghost, int muted)
{
    pump_kit(1, 45, 0, 26);
    song.g[G_CGHOST] = (int16_t)ghost;
    trk[0].p[P_MUTE] = (int16_t)muted;
}

/* LFO demos (4 bars at 120 BPM each): a hat pattern with LFO 1 on TONE, a cymbal with LFO 1 on LVL, a kick with
 * LFO 1 on PAN: every waveform in turn, one bar each, SYNC 1/4 .. */
static void lfo_kit(uint32_t dest)
{
    uint32_t k;
    host_init();
    old_set_model(&trk[0], dest == 9u ? DM_CYMB : dest == 10u ? DM_K909 : DM_HATC);
    for (k = 0; k < 16u; k += dest == 3u ? 1u : 4u)
        trk[0].step[k].on = 1;
    if (dest == 9u)
        trk[0].p[P_E1] = 120;
    trk[0].p[P_LFO1 + LF_DEST] = (int16_t)dest;
    trk[0].p[P_LFO1 + LF_DEPTH] = 56;
    trk[0].p[P_LFO1 + LF_RATE] = 52;                 /* 1/4 */
    trk[0].p[P_LFO1 + LF_MORPH] = 40;
}

static void lfo_wave_bar(uint32_t b) { trk[0].p[P_LFO1 + LF_WAVE] = (int16_t)(b % LW_COUNT); }

/* RESON demos (120 BPM): a kick / snare / hat kit with RESON on the snare and hats */
static void reson_kit(uint32_t model)
{
    uint32_t k;
    host_init();
    old_set_model(&trk[0], DM_K909);
    old_set_model(&trk[1], DM_S909);
    old_set_model(&trk[2], DM_HATC);
    for (k = 0; k < 16u; k += 4u)
        trk[0].step[k].on = 1;
    trk[1].step[4].on = trk[1].step[12].on = 1;
    for (k = 2; k < 16u; k += 4u)
        trk[2].step[k].on = 1;
    for (k = 1; k < 3u; k++) {
        trk[k].p[P_RMODEL] = (int16_t)model;
        trk[k].p[P_RDECAY] = 96;
        trk[k].p[P_RMIX] = 90;
    }
    trk[2].p[P_RTUNE] = 72;
}
static void reson_model_bar(uint32_t b) { trk[1].p[P_RMODEL] = trk[2].p[P_RMODEL] = (int16_t)(RS_STRNG + b % 3u); }
static void reson_chord_bar(uint32_t b) { trk[1].p[P_RSTRCT] = (int16_t)((b % RS_NCHORD) * 128u / RS_NCHORD + 3u); }
static void reson_dist_bar(uint32_t b) { trk[1].p[P_DIST] = trk[2].p[P_DIST] = (int16_t)(b & 1u ? 110 : 0); }
static void reson_none_bar(uint32_t b) { (void)b; }

/* sound pack demos (120 BPM, whole mix). sp_speaker_eq.wav: the 808 kit, 2 bars each FLAT, LOWCUT, BASS+;
 * sp_reverb.wav: a snare on 2 and 4 into the reverb, 2 bars each ROOM, SPRING at SIZE 0 / 64 / 127 (DAMP 60), SPRING
 * SIZE 127 DAMP 0 and DAMP 127; sp_slow_div.wav: a 1/16 kick with a hat on 2BAR (4 bars) then 4BAR (8 bars), the
 * snare's delay at TIME 1/2 */
static void sp_kit(void)
{
    static const char *const PAT[3] = {"X...x...x...x...", "....X.......X...", "x.x.x.x.x.x.x.x."};
    static const uint32_t MODEL[3] = {DM_K808, DM_S808, DM_HATC};
    uint32_t i, k;
    host_init();
    for (i = 0; i < 3u; i++) {
        old_set_model(&trk[i], MODEL[i]);
        for (k = 0; k < 16u; k++) {
            trk[i].step[k].on = PAT[i][k] != '.';
            trk[i].step[k].acc = PAT[i][k] == 'X';
        }
    }
}
static void sp_eq_bar(uint32_t b) { fx_lowcut = (uint8_t)(b / 2u < 3u ? b / 2u : 2u); }
static void sp_rev_bar(uint32_t b)
{
    static const int16_t TYPE[6] = {0, 1, 1, 1, 1, 1}, SIZE[6] = {90, 0, 64, 127, 127, 127}, DAMP[6] = {60, 60, 60, 60, 0, 127};
    uint32_t s = b / 2u < 6u ? b / 2u : 5u;
    song.g[G_RTYPE] = TYPE[s];
    song.g[G_RSIZE] = SIZE[s];
    song.g[G_RDAMP] = DAMP[s];
}
static void sp_div_bar(uint32_t b) { trk[2].p[P_SDIV] = b < 4u ? 8 : 9; }
static void write_sound_pack(const char *dir)
{
    sp_kit();
    write_demo(dir, "sp_speaker_eq.wav", 6, sp_eq_bar);
    fx_lowcut = 0;
    sp_kit();
    old_set_model(&trk[0], DM_K808);
    memset(trk[0].step, 0, sizeof trk[0].step);      /* the snare alone */
    memset(trk[2].step, 0, sizeof trk[2].step);
    trk[1].p[P_REV] = 110;
    write_demo(dir, "sp_reverb.wav", 12, sp_rev_bar);
    song.g[G_RTYPE] = 0;
    sp_kit();
    trk[1].p[P_DLY] = 90;
    song.g[G_DTIME] = 6;                             /* 1/2 */
    for (uint32_t k = 0; k < 16u; k++)
        trk[2].step[k].on = 1;
    write_demo(dir, "sp_slow_div.wav", 12, sp_div_bar);
}

/* PERFORM demos (120 BPM, the sound pack's 808 kit with a reverb / delay send): 4 bars each, the effect (a key or a
 * knob) held over bars 2 and 3: pf_<name>.wav */
static const struct { const char *name; uint32_t held; int8_t k[4]; } PF_DEMO[] = {
    {"pf_repeat_8.wav", 1u << PF_R8, {0}}, {"pf_repeat_16.wav", 1u << PF_R16, {0}},
    {"pf_repeat_32.wav", 1u << PF_R32, {0}}, {"pf_reverse.wav", 1u << PF_REV, {0}},
    {"pf_tape_stop.wav", 1u << PF_TAPE, {0}}, {"pf_lpf.wav", 1u << PF_LPF, {0}}, {"pf_hpf.wav", 1u << PF_HPF, {0}},
    {"pf_freeze.wav", 1u << PF_FRZ, {0}}, {"pf_oct_up.wav", 1u << PF_OUP, {0}}, {"pf_oct_dn.wav", 1u << PF_ODN, {0}},
    {"pf_oct_up_shimmer.wav", 1u << PF_OUP, {0, 0, 0, 60}}, {"pf_mute_kick.wav", 1u << PF_M1, {0}},
    {"pf_crush.wav", 0, {0, 80, 0, 0}}, {"pf_throw.wav", 0, {0, 0, 100, 0}}, {"pf_filter_knob.wav", 0, {-70, 0, 0, 0}},
};
static uint32_t pf_cur;
static void pf_bar(uint32_t b)
{
    uint32_t on = b == 1u || b == 2u, k;
    perf_held = on ? PF_DEMO[pf_cur].held : 0u;
    for (k = 0; k < 4u; k++)
        perf_k[k] = on ? PF_DEMO[pf_cur].k[k] : 0;
}
static void write_perform(const char *dir)
{
    for (pf_cur = 0; pf_cur < sizeof PF_DEMO / sizeof PF_DEMO[0]; pf_cur++) {
        sp_kit();
        trk[1].p[P_REV] = 60;
        trk[2].p[P_DLY] = 50;
        write_demo(dir, PF_DEMO[pf_cur].name, 4, pf_bar);
        perf_held = 0;
    }
}

/* MOTION demo (120 BPM): the 808 kit, the kick's DECAY recorded as a sweep over a bar (step k: 10 + 7 k); bar 1
 * PLAY OFF (the patch), bars 2..4 PLAY ON: motion_decay.wav */
static void motion_bar(uint32_t b) { mo.b.on = b ? 1u : 0u; }
static void write_motion(const char *dir)
{
    uint32_t k;
    sp_kit();
    for (k = 0; k < 16u; k++)
        trk[0].step[k].on = (k & 1u) == 0u;           /* the kick on every 1/8: the sweep is heard */
    for (k = 0; k < 16u; k++)
        motion_add(0, k, P_E1, (int32_t)(10u + 7u * k));
    write_demo(dir, "motion_decay.wav", 4, motion_bar);
    memset(&mo, 0, sizeof mo);
}

/* parameter locks A/B (120 BPM, 4 bars): the 808 kit, the kick on every 1/8 and on steps 3 7 11 15, through the LP
 * FILTER; locks_on.wav: those four steps lock its DECAY (E1) long and the CUT low, snapping back after each;
 * locks_off.wav: the same pattern without them */
static void locks_bar(uint32_t b) { (void)b; }
static void write_locks(const char *dir, int on)
{
    uint32_t k;
    sp_kit();
    for (k = 0; k < 16u; k++)
        trk[0].step[k].on = (k & 1u) == 0u || (k & 3u) == 3u;
    trk[0].p[P_FTYPE] = FT_LP;
    trk[0].p[P_FCUT] = 100;
    trk[0].p[P_E1] = 30;
    for (k = 3; on && k < 16u; k += 4u) {
        lock_set(0, k, P_E1, 120);
        lock_set(0, k, P_FCUT, 25);
    }
    write_demo(dir, on ? "locks_on.wav" : "locks_off.wav", 4, locks_bar);
    memset(&mo, 0, sizeof mo);
}

/* SONG: A (four on the floor + hats) x2, B (a broken kick + snare) x1, LOOP ON: 6 bars, the rows change on the bar */
static step_t song_st[2][NTRK][NSTEP];
static void song_bar(uint32_t b) { (void)b; }
static void write_song(const char *dir)
{
    static const char *const PAT[2][3] = {{"X...x...x...x...", "................", "x.x.x.x.x.x.x.x."},
                                          {"X.....x...x.....", "....X.......X..x", "x.xxx.x.x.xxx.x."}};
    uint32_t s, i, k;
    sp_kit();
    memset(song_st, 0, sizeof song_st);
    for (s = 0; s < 2u; s++) {
        chain.src[s].m = &LK_NONE;
        for (k = 0; k < NTRK; k++) {
            chain.src[s].step[k] = song_st[s][k];
            chain.src[s].timing[k][0] = 16;
            chain.src[s].timing[k][1] = 2;
            chain.src[s].timing[k][2] = 0;
            chain.src[s].timing[k][3] = 0;
            chain.src[s].model[k] = (uint8_t)trk[k].p[P_MODEL];
        }
        for (i = 0; i < 3u; i++)
            for (k = 0; k < 16u; k++) {
                song_st[s][i][k].on = PAT[s][i][k] != '.';
                song_st[s][i][k].acc = PAT[s][i][k] == 'X';
            }
    }
    chain.cfg.count = 2;
    chain.cfg.loop = 1;
    chain.cfg.row[0] = (chain_row_t){0, 2};
    chain.cfg.row[1] = (chain_row_t){1, 1};
    chain.armed = 1;
    write_demo(dir, "song_a2_b1_loop.wav", 6, song_bar);
    transport_req = 2;
    render_mix(L, R, CTL);
    memset(&chain, 0, sizeof chain);
}

/* PHYS: MEMB voicings and MODAL on RESON, 4 bars each of a 1/4 pattern on track 1 */
static void phys_bar(uint32_t b) { (void)b; }
static void phys_demo(const char *dir, const char *name, uint32_t model, const int16_t *e, int16_t rs, const int16_t *r)
{
    uint32_t k;
    host_init();
    old_set_model(&trk[0], model);
    for (k = 0; k < 7u && e; k++)
        if (e[k] != -99)
            trk[0].p[P_E0 + k] = e[k];
    for (k = 0; k < 16u; k += 4u)
        trk[0].step[k].on = 1;
    trk[0].step[0].acc = 1;
    if (rs) {
        trk[0].p[P_RMODEL] = rs;
        trk[0].p[P_RTUNE] = r[0];
        trk[0].p[P_RDECAY] = r[1];
        trk[0].p[P_RMIX] = r[2];
        trk[0].p[P_RTONE] = r[3];
        trk[0].p[P_RSTRCT] = r[4];
        trk[0].p[P_RPOS] = r[5];
    }
    write_demo(dir, name, 4, phys_bar);
    transport_req = 2;
    render_mix(L, R, CTL);
}
static void write_phys(const char *dir)
{
    /* MEMB knobs: TUNE DECAY TONE HEAD POS BEND STICK (-99: the old default) */
    static const int16_t TOM[7] = {-99, -99, -99, 10, -99, 30, -99}, TIMP[7] = {-12, 110, -99, 0, 30, -99, -99};
    static const int16_t TABLA[7] = {7, -99, -99, 120, -99, 60, 50}, RIM[7] = {-99, -99, -99, -99, 127, -99, 90};
    /* RESON: TUNE DECAY MIX TONE STRCT POS */
    static const int16_t PLATE[6] = {48, 90, 80, 80, 110, 20}, BELL[6] = {72, 100, 90, 100, 120, 10}, BAR[6] = {60, 80, 90, 70, 70, 20};
    phys_demo(dir, "memb_tom.wav", DM_MEMB, TOM, 0, 0);
    phys_demo(dir, "memb_timpani.wav", DM_MEMB, TIMP, 0, 0);
    phys_demo(dir, "memb_tabla.wav", DM_MEMB, TABLA, 0, 0);
    phys_demo(dir, "memb_rim.wav", DM_MEMB, RIM, 0, 0);
    phys_demo(dir, "modal_kick_plate.wav", DM_K909, 0, RS_MODAL, PLATE);
    phys_demo(dir, "modal_snare_bell.wav", DM_S909, 0, RS_MODAL, BELL);
    phys_demo(dir, "modal_clap_bar.wav", DM_C909, 0, RS_MODAL, BAR);
}

/* FILTER demos (filter.c), 120 BPM, 4 bars: one track on a pattern, its filter set; the LP sweep raises CUT
 * bar by bar */
static void filter_bar_none(uint32_t b) { (void)b; }
static void filter_bar_sweep(uint32_t b) { trk[0].p[P_FCUT] = (int16_t)(20 + b * 33); }
static void filter_one(const char *dir, const char *name, uint32_t mi, const char *pat, int ty, int cut, int reso,
                       int env, int dec, void (*bar)(uint32_t b))
{
    uint32_t k;
    host_init();
    old_set_model(&trk[0], mi);
    for (k = 0; k < 16u; k++)
        trk[0].step[k].on = pat[k] == 'x';
    trk[0].p[P_FTYPE] = (int16_t)ty;
    trk[0].p[P_FCUT] = (int16_t)cut;
    trk[0].p[P_FRESO] = (int16_t)reso;
    trk[0].p[P_FENV] = (int16_t)env;
    trk[0].p[P_FDEC] = (int16_t)dec;
    if (mi == DM_C909) {                             /* the clap: LFO 1 on F.CUT, a sine at 1/4 */
        trk[0].p[P_LFO1 + LF_WAVE] = LW_SINE;
        trk[0].p[P_LFO1 + LF_MODE] = LM_SYNC;
        trk[0].p[P_LFO1 + LF_RATE] = 48;
        trk[0].p[P_LFO1 + LF_DEPTH] = 50;
        trk[0].p[P_LFO1 + LF_DEST] = 17;
    }
    write_demo(dir, name, 4, bar);
}

static void write_filter(const char *dir)
{
    filter_one(dir, "filter_lp_sweep.wav", DM_S909, "x.x.x.x.x.x.x.x.", FT_LP, 20, 80, 0, 40, filter_bar_sweep);
    filter_one(dir, "filter_hp_hats.wav", DM_HATC, "xxxxxxxxxxxxxxxx", FT_HP, 90, 100, 0, 40, filter_bar_none);
    filter_one(dir, "filter_notch_cymb.wav", DM_CYMB, "x...............", FT_NOTCH, 85, 0, 0, 40, filter_bar_none);
    filter_one(dir, "filter_kick_env.wav", DM_K808, "x...x...x...x...", FT_LP, 60, 40, -40, 50, filter_bar_none);
    filter_one(dir, "filter_lfo_clap.wav", DM_C909, "....x.......x...", FT_BP, 60, 70, 0, 40, filter_bar_none);
}

/* FM demos: one track, 4 bars at 120 BPM */
static void fm_one(const char *dir, const char *name, const int16_t *k, const char *pat)
{
    uint32_t i;
    host_init();
    old_set_model(&trk[0], DM_FM);
    for (i = 0; i < 8u; i++)
        trk[0].p[P_E0 + i] = k[i];
    for (i = 0; i < 16u; i++)
        trk[0].step[i].on = pat[i] == 'x';
    write_demo(dir, name, 4, filter_bar_none);
}

static void write_fm(const char *dir)
{
    /* TUNE DECAY INDEX RATIO MDEC SWEEP FBK VEL (RATIO: index into 0.5 1 1.41 1.5 2 2.76 3 3.5 4 5.4 ...) */
    static const int16_t BELL[8] = {19, 110, 70, 7, 90, 0, 0, 64}, MTOM[8] = {-10, 80, 50, 2, 30, 20, 20, 64};
    static const int16_t WOOD[8] = {12, 25, 40, 5, 10, 0, 0, 64}, ZAP[8] = {12, 50, 90, 1, 25, 110, 0, 64};
    static const int16_t KICK[8] = {-24, 70, 30, 1, 15, 60, 0, 64};
    fm_one(dir, "fm_bell.wav", BELL, "x.......x.......");
    fm_one(dir, "fm_metal_tom.wav", MTOM, "x..x..x...x.x...");
    fm_one(dir, "fm_woodblock.wav", WOOD, "x.x.xx.x.x.xx.x.");
    fm_one(dir, "fm_zap.wav", ZAP, "x...x...x...x.x.");
    fm_one(dir, "fm_kick.wav", KICK, "x...x...x...x...");
}

/* KTRX demos: one track, 4 bars at 120 BPM (TUNE DECAY SWEEP SDEC PUNCH NOISE SUB CLIP) */
static void ktrx_one(const char *dir, const char *name, const int16_t *k, const char *pat)
{
    uint32_t i;
    host_init();
    old_set_model(&trk[0], DM_KTRX);
    for (i = 0; i < 8u; i++)
        trk[0].p[P_E0 + i] = k[i];
    for (i = 0; i < 16u; i++)
        trk[0].step[i].on = pat[i] == 'x';
    write_demo(dir, name, 4, filter_bar_none);
}

static void write_ktrx(const char *dir)
{
    static const int16_t DEF[8] = {0, 64, 64, 32, 0, 0, 0, 0}, BOOM[8] = {-5, 100, 40, 90, 0, 0, 90, 0};
    static const int16_t PUNCH[8] = {3, 50, 80, 20, 127, 70, 0, 0}, ZAP[8] = {7, 60, 127, 50, 0, 0, 0, 0};
    static const int16_t DIRT[8] = {0, 70, 60, 30, 60, 40, 0, 120};
    ktrx_one(dir, "ktrx_default.wav", DEF, "x...x...x...x...");
    ktrx_one(dir, "ktrx_boom_sub.wav", BOOM, "x.........x.....");
    ktrx_one(dir, "ktrx_punch_noise.wav", PUNCH, "x...x...x...x.x.");
    ktrx_one(dir, "ktrx_zap.wav", ZAP, "x..x..x...x.x...");
    ktrx_one(dir, "ktrx_clip.wav", DIRT, "x...x...x...x...");
}

/* CBTRX CHTRX OHTRX CYTRX demos: 4 bars at 120 BPM; track 0 the model (its knobs in its page order), hats_choke: a
 * closed hat on track 0 cutting an open one on track 1 (choke group 1) */
static void trxm_one(const char *dir, const char *name, uint32_t mi, const int16_t *k, const char *pat)
{
    uint32_t i;
    host_init();
    old_set_model(&trk[0], mi);
    for (i = 0; i < 8u; i++)
        trk[0].p[P_E0 + i] = k[i];
    for (i = 0; i < 16u; i++) {
        trk[0].step[i].on = pat[i] == 'x' || pat[i] == 'X';
        trk[0].step[i].acc = pat[i] == 'X';
    }
    write_demo(dir, name, 4, filter_bar_none);
}

static void write_trxmetal(const char *dir)
{
    static const int16_t CB[8] = {0, 64, 0, 0, 64, 0, 64, 0}, CBE[8] = {0, 80, 64, 0, 90, 40, 64, 0},
                         CBD[8] = {-5, 50, 0, 100, 64, 0, 64, 0};
    static const int16_t CH[8] = {0, 64, 64, 0, 127, 64, 0, 0}, CHM[8] = {0, 30, 40, 64, 100, 127, 0, 0},
                         CHN[8] = {0, 20, 30, 100, 127, 0, 0, 0};
    static const int16_t OH[8] = {0, 64, 64, 0, 127, 64, 0, 0}, OHD[8] = {0, 127, 64, 0, 127, 100, 0, 0};
    static const int16_t CY[8] = {0, 64, 64, 64, 64, 64, 0, 0}, CYP[8] = {0, 100, 100, 90, 80, 64, 100, 0},
                         CYS[8] = {-3, 40, 127, 127, 127, 20, 30, 0};
    uint32_t i;
    trxm_one(dir, "cbtrx_default.wav", DM_CBTRX, CB, "x..x..x.x..x..x.");
    trxm_one(dir, "cbtrx_enh.wav", DM_CBTRX, CBE, "X..x..x.X..x.x..");
    trxm_one(dir, "cbtrx_damp.wav", DM_CBTRX, CBD, "x.x.x.x.x.x.x.x.");
    trxm_one(dir, "chtrx_default.wav", DM_CHTRX, CH, "x.x.x.x.x.x.x.x.");
    trxm_one(dir, "chtrx_metal.wav", DM_CHTRX, CHM, "xxXxxxXxxxXxxxXx");
    trxm_one(dir, "chtrx_noise.wav", DM_CHTRX, CHN, "x.xxx.xxx.xxx.xX");
    trxm_one(dir, "ohtrx_default.wav", DM_OHTRX, OH, "..x...x...x...x.");
    trxm_one(dir, "ohtrx_dip.wav", DM_OHTRX, OHD, "x.......x.......");
    trxm_one(dir, "cytrx_default.wav", DM_CYTRX, CY, "x...............");
    trxm_one(dir, "cytrx_peak.wav", DM_CYTRX, CYP, "x.......x.......");
    trxm_one(dir, "cytrx_small.wav", DM_CYTRX, CYS, "x...x...x...x...");
    host_init();                                    /* the choke: CH on track 0, OH on track 1 (group 1) */
    old_set_model(&trk[0], DM_CHTRX);
    old_set_model(&trk[1], DM_OHTRX);
    trk[0].p[P_CHOKE] = trk[1].p[P_CHOKE] = 1;
    for (i = 0; i < 16u; i++) {
        trk[0].step[i].on = (i & 1u) == 0 && (i & 3u) != 2u;
        trk[1].step[i].on = (i & 3u) == 2u;
    }
    write_demo(dir, "trx_hats_choke.wav", 4, filter_bar_none);
}

/* CPTRX / MATRX demos: one track, 4 bars at 120 BPM */
static void trxn_one(const char *dir, const char *name, uint32_t mi, const int16_t *k, const char *pat)
{
    uint32_t i;
    host_init();
    old_set_model(&trk[0], mi);
    for (i = 0; i < 8u; i++)
        trk[0].p[P_E0 + i] = k[i];
    for (i = 0; i < 16u; i++)
        trk[0].step[i].on = pat[i] == 'x';
    write_demo(dir, name, 4, filter_bar_none);
}

static void write_trxn(const char *dir)
{
    /* CPTRX: TUNE DECAY CLPY HARD RATE ROOM RSIZ RTUN */
    static const int16_t CDEF[8] = {0, 64, 64, 64, 64, 0, 64, 64}, CROOM[8] = {-3, 70, 90, 80, 56, 110, 100, 60};
    static const int16_t CSNAP[8] = {6, 20, 40, 100, 30, 0, 64, 64}, CWIDE[8] = {-6, 110, 127, 40, 110, 60, 80, 40};
    /* MATRX: TUNE DECAY ATT REV DAMP RATL TONE HARD */
    static const int16_t MDEF[8] = {0, 64, 0, 0, 0, 0, 64, 64}, MSHAK[8] = {0, 30, 0, 0, 60, 0, 90, 80};
    static const int16_t MSWEL[8] = {-2, 90, 70, 60, 30, 90, 50, 64}, MRATL[8] = {3, 127, 10, 0, 100, 127, 40, 30};
    trxn_one(dir, "cptrx_default.wav", DM_CPTRX, CDEF, "....x.......x...");
    trxn_one(dir, "cptrx_room.wav", DM_CPTRX, CROOM, "....x.......x..x");
    trxn_one(dir, "cptrx_snap.wav", DM_CPTRX, CSNAP, "....x..x....x...");
    trxn_one(dir, "cptrx_wide.wav", DM_CPTRX, CWIDE, "....x.......x...");
    trxn_one(dir, "matrx_default.wav", DM_MATRX, MDEF, "x.x.x.x.x.x.x.x.");
    trxn_one(dir, "matrx_shaker.wav", DM_MATRX, MSHAK, "xxxxxxxxxxxxxxxx");
    trxn_one(dir, "matrx_swell.wav", DM_MATRX, MSWEL, "x...x...x...x...");
    trxn_one(dir, "matrx_rattle.wav", DM_MATRX, MRATL, "x.....x.....x...");
}

/* SDTRX, B2TRX demos: one track, 4 bars at 120 BPM (SDTRX: TUNE DECAY SNAP TONE BUMP BENV CLIP; B2TRX: TUNE DECAY RAMP
 * HOLD TICK NOISE DIRT DIST) */
static void trx_one(const char *dir, const char *name, uint32_t model, const int16_t *k, const char *pat)
{
    uint32_t i;
    host_init();
    old_set_model(&trk[0], model);
    for (i = 0; i < 8u; i++)
        trk[0].p[P_E0 + i] = k[i];
    for (i = 0; i < 16u; i++)
        trk[0].step[i].on = pat[i] == 'x';
    write_demo(dir, name, 4, filter_bar_none);
}

static void write_sdtrx_b2trx(const char *dir)
{
    static const int16_t SDEF[8] = {0, 64, 64, 64, 0, 64, 0, 0}, SRING[8] = {-3, 100, 40, 100, 60, 40, 0, 0};
    static const int16_t SCRACK[8] = {2, 40, 127, 30, 90, 0, 0, 0}, SCLIP[8] = {0, 64, 80, 64, 0, 64, 120, 0};
    static const int16_t BDEF[8] = {0, 64, 0, 0, 0, 0, 0, 0}, BBOOM[8] = {-5, 90, 60, 80, 40, 0, 0, 0};
    static const int16_t BDIRT[8] = {0, 70, 40, 0, 60, 40, 104, 0}, BDIST[8] = {3, 64, 90, 20, 80, 0, 0, 64};
    trx_one(dir, "sdtrx_default.wav", DM_SDTRX, SDEF, "....x.......x...");
    trx_one(dir, "sdtrx_ring.wav", DM_SDTRX, SRING, "....x.......x..x");
    trx_one(dir, "sdtrx_crack.wav", DM_SDTRX, SCRACK, "....x...x...x.x.");
    trx_one(dir, "sdtrx_clip.wav", DM_SDTRX, SCLIP, "....x.......x...");
    trx_one(dir, "b2trx_default.wav", DM_B2TRX, BDEF, "x...x...x...x...");
    trx_one(dir, "b2trx_boom.wav", DM_B2TRX, BBOOM, "x.........x.....");
    trx_one(dir, "b2trx_dirt.wav", DM_B2TRX, BDIRT, "x..x..x...x.x...");
    trx_one(dir, "b2trx_dist.wav", DM_B2TRX, BDIST, "x...x...x...x...");
}

/* XTTRX / XCTRX / CLTRX / RSTRX demos: one track, 4 bars at 120 BPM; nt: the steps' notes (NULL: none) */
static void trxp_one(const char *dir, const char *name, uint32_t mi, const int16_t *k, const char *pat, const int8_t *nt)
{
    uint32_t i;
    host_init();
    old_set_model(&trk[0], mi);
    for (i = 0; i < 8u; i++)
        trk[0].p[P_E0 + i] = k[i];
    for (i = 0; i < 16u; i++) {
        trk[0].step[i].on = pat[i] == 'x';
        trk[0].step[i].nt = nt ? nt[i] : 0;
    }
    write_demo(dir, name, 4, filter_bar_none);
}

static void write_trxp(const char *dir)
{
    /* XTTRX / XCTRX: TUNE DECAY RAMP RDEC DAMP DIST DTYP; CLTRX: TUNE DECAY DUAL ENH TUNE2 CLICK; RSTRX: TUNE DECAY
     * DIST */
    static const int16_t XDEF[8] = {0, 64, 0, 64, 0, 0, 0, 0}, XZAP[8] = {-5, 90, 110, 40, 0, 0, 0, 0};
    static const int16_t XDIRT[8] = {0, 80, 30, 64, 40, 110, 127, 0}, CDEF[8] = {0, 64, 0, 0, 64, 0, 0, 0};
    static const int16_t CDUAL[8] = {0, 80, 64, 90, 100, 127, 0, 0}, RDEF[8] = {0, 64, 0, 0, 0, 0, 0, 0};
    static const int16_t RDIST[8] = {-5, 90, 127, 0, 0, 0, 0, 0};
    static const int8_t FILL[16] = {7, 7, 5, 5, 3, 3, 0, 0, -2, -2, -5, -5, -7, -7, -9, -9};
    static const int8_t TUMB[16] = {0, 0, 0, 7, 0, 0, 5, 0, 0, 7, 0, 0, 12, 0, 7, 0};
    trxp_one(dir, "xttrx_default.wav", DM_XTTRX, XDEF, "x...x...x...x...", NULL);
    trxp_one(dir, "xttrx_fill.wav", DM_XTTRX, XDEF, "x.x.x.x.x.x.x.x.", FILL);
    trxp_one(dir, "xttrx_ramp.wav", DM_XTTRX, XZAP, "x..x..x...x.x...", NULL);
    trxp_one(dir, "xttrx_dist.wav", DM_XTTRX, XDIRT, "x...x...x...x.x.", NULL);
    trxp_one(dir, "xctrx_default.wav", DM_XCTRX, XDEF, "x..x..x...x.x...", TUMB);
    trxp_one(dir, "xctrx_dist.wav", DM_XCTRX, XDIRT, "x..x..x...x.x...", TUMB);
    trxp_one(dir, "cltrx_default.wav", DM_CLTRX, CDEF, "x..x..x...x.x...", NULL);
    trxp_one(dir, "cltrx_dual.wav", DM_CLTRX, CDUAL, "x..x..x...x.x...", TUMB);
    trxp_one(dir, "rstrx_default.wav", DM_RSTRX, RDEF, "....x.......x...", NULL);
    trxp_one(dir, "rstrx_dist.wav", DM_RSTRX, RDIST, "..x...x.x...x..x", NULL);
}

/* BDEFM / XTEFM demos: one track, 4 bars at 120 BPM (TUNE DECAY RAMP RDEC MOD MFRQ MDEC MFB / CLIC); nt: the steps'
 * notes (NULL: none) */
static void bdefm_one(const char *dir, const char *name, uint32_t mi, const int16_t *k, const char *pat, const int8_t *nt)
{
    uint32_t i;
    host_init();
    old_set_model(&trk[0], mi);
    for (i = 0; i < 8u; i++)
        trk[0].p[P_E0 + i] = k[i];
    for (i = 0; i < 16u; i++) {
        trk[0].step[i].on = pat[i] == 'x';
        trk[0].step[i].nt = nt ? nt[i] : 0;
    }
    write_demo(dir, name, 4, filter_bar_none);
}

static void write_bdefm(const char *dir)
{
    static const int16_t BDEF[8] = {0, 64, 0, 64, 64, 64, 64, 0}, BBOOM[8] = {-12, 100, 48, 40, 24, 16, 30, 0};
    static const int16_t BZAP[8] = {-5, 80, 127, 30, 64, 32, 40, 0}, BGRIT[8] = {0, 70, 32, 50, 80, 40, 50, 96};
    static const int16_t XDEF[8] = {0, 64, 0, 64, 64, 64, 64, 0}, XCLEAN[8] = {0, 90, 32, 50, 0, 64, 64, 64};
    static const int16_t XGRIT[8] = {3, 80, 64, 40, 40, 40, 60, 127};
    static const int8_t FILL[16] = {7, 7, 5, 5, 3, 3, 0, 0, -2, -2, -5, -5, -7, -7, -9, -9};
    bdefm_one(dir, "bdefm_default.wav", DM_BDEFM, BDEF, "x...x...x...x...", NULL);
    bdefm_one(dir, "bdefm_boom.wav", DM_BDEFM, BBOOM, "x.........x.....", NULL);
    bdefm_one(dir, "bdefm_zap.wav", DM_BDEFM, BZAP, "x..x..x...x.x...", NULL);
    bdefm_one(dir, "bdefm_grit.wav", DM_BDEFM, BGRIT, "x...x...x...x.x.", NULL);
    bdefm_one(dir, "xtefm_default.wav", DM_XTEFM, XDEF, "x...x...x...x...", NULL);
    bdefm_one(dir, "xtefm_clean_fill.wav", DM_XTEFM, XCLEAN, "x.x.x.x.x.x.x.x.", FILL);
    bdefm_one(dir, "xtefm_grit.wav", DM_XTEFM, XGRIT, "x..x..x...x.x...", NULL);
}

/* SDEFM / CPEFM / RSEFM demos: one track, 4 bars at 120 BPM; nt: the steps' notes (NULL: none) */
static void efmn_one(const char *dir, const char *name, uint32_t mi, const int16_t *k, const char *pat, const int8_t *nt)
{
    uint32_t i;
    host_init();
    old_set_model(&trk[0], mi);
    for (i = 0; i < 8u; i++)
        trk[0].p[P_E0 + i] = k[i];
    for (i = 0; i < 16u; i++) {
        trk[0].step[i].on = pat[i] == 'x';
        trk[0].step[i].nt = nt ? nt[i] : 0;
    }
    write_demo(dir, name, 4, filter_bar_none);
}

static void write_efmn(const char *dir)
{
    /* SDEFM: TUNE DECAY NOIS NDEC MOD MFRQ MDEC HPF */
    static const int16_t SDEF[8] = {0, 64, 64, 64, 64, 64, 64, 0}, SRING[8] = {-3, 96, 30, 50, 24, 32, 90, 0};
    static const int16_t SCRSH[8] = {2, 50, 110, 80, 127, 100, 40, 24};
    /* CPEFM: TUNE DECAY CLPS CDEC MOD MFRQ MDEC HPF */
    static const int16_t CDEF[8] = {0, 64, 64, 64, 64, 64, 64, 0}, CWIDE[8] = {-5, 80, 127, 100, 90, 16, 100, 0};
    static const int16_t CTONE[8] = {-12, 50, 32, 40, 0, 64, 64, 0};
    /* RSEFM: TUNE DECAY MOD HPF SNAR SPTC SDEC SMOD */
    static const int16_t RDEF[8] = {0, 64, 64, 0, 64, 64, 64, 64}, RRIM[8] = {0, 40, 20, 16, 0, 64, 64, 64};
    static const int16_t RSNR[8] = {-2, 50, 100, 32, 127, 40, 80, 127};
    static const int8_t TUMB[16] = {0, 0, 0, 7, 0, 0, 5, 0, 0, 7, 0, 0, 12, 0, 7, 0};
    efmn_one(dir, "sdefm_default.wav", DM_SDEFM, SDEF, "....x.......x...", NULL);
    efmn_one(dir, "sdefm_ring.wav", DM_SDEFM, SRING, "....x.......x..x", NULL);
    efmn_one(dir, "sdefm_crush.wav", DM_SDEFM, SCRSH, "....x..x....x.x.", NULL);
    efmn_one(dir, "cpefm_default.wav", DM_CPEFM, CDEF, "....x.......x...", NULL);
    efmn_one(dir, "cpefm_wide.wav", DM_CPEFM, CWIDE, "....x.......x...", NULL);
    efmn_one(dir, "cpefm_tone.wav", DM_CPEFM, CTONE, "x..x..x...x.x...", TUMB);
    efmn_one(dir, "rsefm_default.wav", DM_RSEFM, RDEF, "....x.......x...", NULL);
    efmn_one(dir, "rsefm_rim.wav", DM_RSEFM, RRIM, "x..x..x...x.x...", TUMB);
    efmn_one(dir, "rsefm_snare.wav", DM_RSEFM, RSNR, "....x...x...x..x", NULL);
}

/* ACID demos (120 BPM): track 0 plays a classic 303 figure, the others are empty. nt relative to C4; flags 1 ACC,
 * 2 SLIDE, 4 TIE (not on), 8 rest. acid_reso: RESO 0 -> 127 across 16 bars, CUTOF 30 */
static void acid_kit(int sqr)
{
    static const int8_t NT[16] = {-36, -24, -22, -24, 0, -29, -27, -24, -36, -34, 0, -24, -19, -24, -22, -31};
    static const uint8_t FL[16] = {1, 2, 0, 4, 8, 0, 3, 0, 0, 1, 8, 2, 0, 1, 4, 2};
    uint32_t k;
    host_init();
    old_set_model(&trk[0], DM_ACID);
    for (k = 0; k < 16u; k++) {
        trk[0].step[k].on = !(FL[k] & 12u);
        trk[0].step[k].acc = FL[k] & 1u;
        trk[0].step[k].slide = (FL[k] >> 1) & 1u;
        trk[0].step[k].tie = (FL[k] >> 2) & 1u;
        trk[0].step[k].nt = NT[k];
    }
    trk[0].p[P_E6] = (int16_t)sqr;
}

static void acid_reso_bar(uint32_t b)
{
    trk[0].p[P_E2] = 30;
    trk[0].p[P_E3] = (int16_t)(b * 127u / 15u);
}

/* CBEFM HHEFM CYEFM demos: 4 bars at 120 BPM; track 0 the model (its knobs in its page order); efm_hats_choke: HHEFM
 * on track 0 and HATO on track 1 (choke group 1) */
static void efmm_one(const char *dir, const char *name, uint32_t mi, const int16_t *k, const char *pat)
{
    uint32_t i;
    host_init();
    old_set_model(&trk[0], mi);
    for (i = 0; i < 8u; i++)
        trk[0].p[P_E0 + i] = k[i];
    for (i = 0; i < 16u; i++) {
        trk[0].step[i].on = pat[i] == 'x' || pat[i] == 'X';
        trk[0].step[i].acc = pat[i] == 'X';
    }
    write_demo(dir, name, 4, filter_bar_none);
}

static void write_efmmetal(const char *dir)
{
    static const int16_t CB[8] = {0, 64, 0, 0, 64, 64, 64, 0}, CBS[8] = {0, 96, 96, 0, 80, 64, 40, 0},
                         CBF[8] = {-5, 70, 40, 40, 40, 32, 80, 0};
    static const int16_t HH[8] = {0, 64, 0, 64, 64, 64, 64, 0}, HHT[8] = {0, 110, 100, 100, 64, 64, 64, 0},
                         HHF[8] = {0, 40, 0, 64, 32, 96, 64, 16};
    static const int16_t CY[8] = {0, 64, 0, 0, 64, 64, 64, 0}, CYB[8] = {0, 100, 24, 64, 96, 20, 100, 0},
                         CYS[8] = {3, 40, 8, 96, 32, 127, 32, 0};
    uint32_t i;
    efmm_one(dir, "cbefm_default.wav", DM_CBEFM, CB, "x..x..x.x..x..x.");
    efmm_one(dir, "cbefm_snap.wav", DM_CBEFM, CBS, "X..x..x.X..x.x..");
    efmm_one(dir, "cbefm_fb.wav", DM_CBEFM, CBF, "x.x.x.x.x.x.x.x.");
    efmm_one(dir, "hhefm_default.wav", DM_HHEFM, HH, "x.x.x.x.x.x.x.x.");
    efmm_one(dir, "hhefm_trem.wav", DM_HHEFM, HHT, "..x...x...x...x.");
    efmm_one(dir, "hhefm_fb.wav", DM_HHEFM, HHF, "xxXxxxXxxxXxxxXx");
    efmm_one(dir, "cyefm_default.wav", DM_CYEFM, CY, "x...............");
    efmm_one(dir, "cyefm_bright.wav", DM_CYEFM, CYB, "x.......x.......");
    efmm_one(dir, "cyefm_short.wav", DM_CYEFM, CYS, "x...x...x...x...");
    host_init();                                    /* the choke: HHEFM on track 0, HATO on track 1 (group 1) */
    old_set_model(&trk[0], DM_HHEFM);
    old_set_model(&trk[1], DM_HATO);
    trk[0].p[P_CHOKE] = trk[1].p[P_CHOKE] = 1;
    for (i = 0; i < 16u; i++) {
        trk[0].step[i].on = (i & 1u) == 0 && (i & 3u) != 2u;
        trk[1].step[i].on = (i & 3u) == 2u;
    }
    write_demo(dir, "efm_hats_choke.wav", 4, filter_bar_none);
}

int main(int argc, char **argv)
{
    const char *dir = argc > 1 ? argv[1] : "build/drum_renders";
    char path[256];
    uint32_t mi, frames, i, k;
    mkdir(dir, 0755);
    for (mi = 0; mi < NMODELS; mi++) {
        static const uint8_t VEL[4] = {127, 96, 64, 32};
        FILE *f;
        snprintf(path, sizeof path, "%s/%02u_%s.wav", dir, mi, N_MODEL[mi]);
        f = fopen(path, "wb");
        wav_hdr(f, 0);
        frames = 0;
        host_init();
        old_set_model(&trk[0], mi);
        for (i = 0; i < 4; i++)
            hit_and_write(f, &trk[0], VEL[i], &frames);
        for (k = 0; k < 4; k++) {                    /* TUNE, DECAY, TONE, CHAR at low then high */
            const param_desc_t *d = &DMODELS[mi].edit[k];
            int16_t keep = trk[0].p[P_E0 + k];
            trk[0].p[P_E0 + k] = k == 0 ? -12 : d->min;
            hit_and_write(f, &trk[0], 127, &frames);
            trk[0].p[P_E0 + k] = k == 0 ? 12 : d->max;
            hit_and_write(f, &trk[0], 127, &frames);
            trk[0].p[P_E0 + k] = keep;
        }
        fseek(f, 0, SEEK_SET);
        wav_hdr(f, frames);
        fclose(f);
        printf("drumsim: %s\n", path);
    }
    {
        static const char *const PAT[NTRK] = {
            "x...x...x...x..x", "....x.......x...", "....x.......x..x", "x.x.x.x.x.x.x.x.",
            "..x...x...x...x.", "......x....x....", ".x.....x..x.....", "x...............",
        };
        uint32_t total = 8 * 16 * (FS * 60 / 120 / 4) / CTL * CTL;
        FILE *f;
        snprintf(path, sizeof path, "%s/kit.wav", dir);
        f = fopen(path, "wb");
        wav_hdr(f, total);
        host_init();
        for (i = 0; i < NTRK; i++)
            for (k = 0; k < 16; k++)
                trk[i].step[k].on = PAT[i][k] == 'x';
        trk[1].p[P_REV] = 40;
        trk[2].p[P_REV] = 50;
        trk[3].p[P_DLY] = 25;
        transport_req = 1;
        for (frames = 0; frames < total; frames += GAP < total - frames ? GAP : total - frames) {
            uint32_t n = GAP < total - frames ? GAP : total - frames;
            render_mix(L, R, n);
            for (i = 0; i < n; i++)
                wav_put(f, L[i], R[i]);
        }
        fclose(f);
        printf("drumsim: %s\n", path);
    }
    for (i = 0; i < sizeof KITS / sizeof KITS[0]; i++)
        write_kit(dir, &KITS[i]);
    grids_kit();
    write_demo(dir, "grids_map.wav", 16, map_bar);
    grids_kit();
    write_demo(dir, "grids_euclid.wav", 8, euclid_bar);
    prob_kit();
    write_demo(dir, "prob_ratch.wav", 8, prob_bar);
    pump_kit(0, 45, 0, 26);
    write_demo(dir, "pump_dry.wav", 4, prob_bar);
    pump_kit(1, 45, 0, 26);
    write_demo(dir, "pump_on.wav", 4, prob_bar);
    pump_kit(1, 80, 0, 20);
    write_demo(dir, "pump_rel_sweep.wav", 4, rel_bar);
    pump_kit(1, 45, 127, 26);
    write_demo(dir, "pump_limit.wav", 4, prob_bar);
    ghost_kit(CG_KEEP, 0);
    write_demo(dir, "ghost_keep_heard.wav", 4, prob_bar);
    ghost_kit(CG_KEEP, 1);
    write_demo(dir, "ghost_keep_muted.wav", 4, prob_bar);
    ghost_kit(CG_MUTE, 1);
    write_demo(dir, "ghost_mute_muted.wav", 4, prob_bar);
    ghost_kit(CG_HIDE, 0);
    write_demo(dir, "ghost_hide.wav", 4, prob_bar);
    lfo_kit(3);
    write_demo(dir, "lfo_tone.wav", LW_COUNT, lfo_wave_bar);
    lfo_kit(9);
    write_demo(dir, "lfo_level.wav", LW_COUNT, lfo_wave_bar);
    lfo_kit(10);
    write_demo(dir, "lfo_pan.wav", LW_COUNT, lfo_wave_bar);
    reson_kit(RS_STRNG);
    write_demo(dir, "reson_models.wav", 3, reson_model_bar);   /* STRNG, PIPE, CHORD, one bar each */
    reson_kit(RS_CHORD);
    write_demo(dir, "reson_chords.wav", 8, reson_chord_bar);   /* a chord type per bar */
    reson_kit(RS_STRNG);
    trk[1].p[P_LFO1 + LF_DEST] = 11;                           /* R.TUN: a slow triangle sweep */
    trk[1].p[P_LFO1 + LF_DEPTH] = 48;
    trk[1].p[P_LFO1 + LF_WAVE] = LW_TRI;
    trk[1].p[P_LFO1 + LF_RATE] = 16;                           /* SYNC 2 bars (16 * 17 / 128 = 2) */
    write_demo(dir, "reson_sweep.wav", 4, reson_none_bar);
    reson_kit(RS_PIPE);
    write_demo(dir, "reson_dist.wav", 4, reson_dist_bar);      /* RESON into DIST, every other bar */
    acid_kit(0);
    write_demo(dir, "acid_line.wav", 8, reson_none_bar);
    acid_kit(0);
    write_demo(dir, "acid_reso.wav", 16, acid_reso_bar);
    acid_kit(1);
    write_demo(dir, "acid_sqr.wav", 8, reson_none_bar);
    write_sound_pack(dir);
    write_perform(dir);
    write_motion(dir);
    write_locks(dir, 0);
    write_locks(dir, 1);
    write_song(dir);
    write_phys(dir);
    write_filter(dir);
    write_fm(dir);
    write_ktrx(dir);
    write_trxmetal(dir);
    write_trxn(dir);
    write_sdtrx_b2trx(dir);
    write_trxp(dir);
    write_efmmetal(dir);
    write_efmn(dir);
    write_bdefm(dir);
    return 0;
}
